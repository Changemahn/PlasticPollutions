<?php
$page_title = 'Forgot Password';
require_once 'includes/config.php';
require_once 'includes/functions.php';

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize_input($_POST['email'] ?? '');
    
    if (empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    
    if (empty($errors)) {
        try {
            $pdo = db();
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user) {
                // In a real application, you would send an email with a reset link
                // For this demo, we'll just show a success message
                $success = true;
                set_flash_message('success', 'If an account exists with this email, a password reset link has been sent. (Demo: No actual email sent)');
            } else {
                // Don't reveal if email exists for security
                $success = true;
                set_flash_message('success', 'If an account exists with this email, a password reset link has been sent.');
            }
        } catch (Exception $e) {
            $errors[] = "Request failed: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Reset your password">
    <title>Forgot Password - PlasticPollutions</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main class="container">
        <div class="auth-container">
            <div class="auth-box">
                <h1>Forgot Password</h1>
                <p class="auth-subtitle">Enter your email to reset your password</p>
                
                <?php if (has_flash_message('success')): ?>
                    <div class="alert alert-success">
                        <?php echo htmlspecialchars(get_flash_message('success')); ?>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <?php foreach ($errors as $error): ?>
                            <p><?php echo htmlspecialchars($error); ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="forgot-password.php" class="auth-form">
                    <div class="form-group">
                        <label for="email">Email Address *</label>
                        <input type="email" id="email" name="email" 
                               value="<?php echo htmlspecialchars($email ?? ''); ?>" 
                               required aria-required="true">
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-block">Send Reset Link</button>
                </form>
                
                <p class="auth-footer">
                    Remember your password? <a href="login.php">Login here</a>
                </p>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>
