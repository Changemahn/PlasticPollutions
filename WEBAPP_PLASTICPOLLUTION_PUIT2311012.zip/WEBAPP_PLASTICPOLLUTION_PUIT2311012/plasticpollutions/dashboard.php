<?php
$page_title = 'Dashboard';
require_once 'includes/config.php';
require_once 'includes/functions.php';

require_login();

$pdo = db();
$user = get_current_user();
$errors = [];
$success = false;

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    $first_name = sanitize_input($_POST['first_name'] ?? '');
    $last_name = sanitize_input($_POST['last_name'] ?? '');
    $email = sanitize_input($_POST['email'] ?? '');
    
    if (empty($first_name) || !preg_match("/^[a-zA-Z\s]{2,50}$/", $first_name)) {
        $errors[] = "Invalid first name";
    }
    
    if (empty($last_name) || !preg_match("/^[a-zA-Z\s]{2,50}$/", $last_name)) {
        $errors[] = "Invalid last name";
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email";
    }
    
    if (empty($errors)) {
        try {
            // Check if email is taken by another user
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->execute([$email, $_SESSION['user_id']]);
            
            if ($stmt->rowCount() > 0) {
                $errors[] = "Email already in use";
            } else {
                $stmt = $pdo->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ? WHERE id = ?");
                $stmt->execute([$first_name, $last_name, $email, $_SESSION['user_id']]);
                
                $_SESSION['first_name'] = $first_name;
                $_SESSION['email'] = $email;
                
                $success = true;
                set_flash_message('success', 'Profile updated successfully!');
            }
        } catch (Exception $e) {
            $errors[] = "Update failed: " . $e->getMessage();
        }
    }
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    if (empty($current_password)) {
        $errors[] = "Current password is required";
    }
    
    if (empty($new_password) || strlen($new_password) < 8) {
        $errors[] = "New password must be at least 8 characters";
    }
    
    if (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/", $new_password)) {
        $errors[] = "Password must contain uppercase, lowercase, number, and special character";
    }
    
    if ($new_password !== $confirm_password) {
        $errors[] = "Passwords do not match";
    }
    
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user_data = $stmt->fetch();
            
            if (!verify_password($current_password, $user_data['password'])) {
                $errors[] = "Current password is incorrect";
            } else {
                $hashed_password = hash_password($new_password);
                $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt->execute([$hashed_password, $_SESSION['user_id']]);
                
                $success = true;
                set_flash_message('success', 'Password changed successfully!');
            }
        } catch (Exception $e) {
            $errors[] = "Password change failed: " . $e->getMessage();
        }
    }
}

// Get user statistics
$donation_count = count(get_user_donations($_SESSION['user_id']));
$total_donations = get_user_total_donations($_SESSION['user_id']);
$pledge_count = $pdo->prepare("SELECT COUNT(*) as count FROM pledges WHERE user_id = ?");
$pledge_count->execute([$_SESSION['user_id']]);
$pledge_count = $pledge_count->fetch()['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="User Dashboard - PlasticPollutions">
    <title>Dashboard - PlasticPollutions</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <div class="dashboard-header">
                <div>
           <h3 style="color: var(--primary-color);">
  Welcome, <?php echo htmlspecialchars($_SESSION['first_name'] ?? 'Guest'); ?>
</h3>

<p style="color: var(--text-light);">
  Visitor ID: <?php echo htmlspecialchars($_SESSION['visitor_id'] ?? 'N/A'); ?>
</p>
                </div>
                <div>
                    <a href="logout.php" class="btn btn-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
            
            <?php if (has_flash_message('success')): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars(get_flash_message('success')); ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error): ?>
                        <p><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <!-- Dashboard Statistics -->
            <div class="dashboard-stats">
                <div class="stat-card">
                    <h3>Total Donations</h3>
                    <div class="value">GHS <?php echo number_format($total_donations); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Donation Count</h3>
                    <div class="value"><?php echo $donation_count; ?></div>
                </div>
                <div class="stat-card">
                    <h3>Active Pledges</h3>
                    <div class="value"><?php echo $pledge_count; ?></div>
                </div>
                <div class="stat-card">
                    <h3>Member Since</h3>
                    <?php 
if (is_array($user) && isset($user['created_at'])) {
    echo date('Y', strtotime($user['created_at']));
} else {
    echo 'N/A'; // or leave empty
}
?>
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 2rem;">
                <!-- Profile Information -->
                <div class="card">
                    <div class="card-header">
                        <h2>Profile Information</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="dashboard.php">
                            <input type="hidden" name="action" value="update_profile">
                            
                            <div class="form-group">
                                <label for="first_name">First Name</label>
                                <input type="text" id="first_name" name="first_name" class="form-control" 
                                       value="<?php echo htmlspecialchars($_SESSION['first_name']); ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="last_name">Last Name</label>
                                <input type="text" id="last_name" name="last_name" class="form-control" 
                                       value="<?php echo htmlspecialchars($_SESSION['last_name']); ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" id="email" name="email" class="form-control" 
                                       value="<?php echo htmlspecialchars($_SESSION['email'] ??''); ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label>Visitor ID</label>
                                <input type="text" class="form-control" 
                                       value="<?php echo htmlspecialchars($_SESSION['visitor_id']); ?>" readonly>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Update Profile</button>
                        </form>
                    </div>
                </div>
                
                <!-- Change Password -->
                <div class="card">
                    <div class="card-header">
                        <h2>Change Password</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="dashboard.php">
                            <input type="hidden" name="action" value="change_password">
                            
                            <div class="form-group">
                                <label for="current_password">Current Password</label>
                                <input type="password" id="current_password" name="current_password" class="form-control" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="new_password">New Password</label>
                                <input type="password" id="new_password" name="new_password" class="form-control" required>
                                <small class="form-text">Minimum 8 characters with uppercase, lowercase, number, and special character</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password</label>
                                <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Change Password</button>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Recent Activity -->
            <div class="card" style="margin-top: 2rem;">
                <div class="card-header">
                    <h2>Recent Activity</h2>
                </div>
                <div class="card-body">
                    <?php
                    $recent_donations = get_user_donations($_SESSION['user_id']);
                    if (empty($recent_donations)):
                    ?>
                        <p style="color: var(--text-light); text-align: center; padding: 2rem;">
                            No recent activity. Start by making a donation or signing a petition!
                        </p>
                    <?php else: ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th>Details</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (array_slice($recent_donations, 0, 5) as $donation): ?>
                                <tr>
                                    <td><i class="fas fa-donate" style="color: var(--primary-color);"></i> Donation</td>
                                    <td>GHS <?php echo number_format($donation['amount']); ?> - <?php echo ucfirst($donation['payment_method']); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($donation['donation_date'])); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="card" style="margin-top: 2rem;">
                <div class="card-header">
                    <h2>Quick Actions</h2>
                </div>
                <div class="card-body">
                    <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
                        <a href="donate.php" class="btn btn-primary">
                            <i class="fas fa-donate"></i> Make a Donation
                        </a>
                        <a href="help.php" class="btn btn-success">
                            <i class="fas fa-hand-holding-heart"></i> Make a Pledge
                        </a>
                        <a href="what-to-do.php" class="btn btn-secondary">
                            <i class="fas fa-file-signature"></i> Sign Petition
                        </a>
                        <a href="contact.php" class="btn btn-outline">
                            <i class="fas fa-envelope"></i> Contact Us
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>
