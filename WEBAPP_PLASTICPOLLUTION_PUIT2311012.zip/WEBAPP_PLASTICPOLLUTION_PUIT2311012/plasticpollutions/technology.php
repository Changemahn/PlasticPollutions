<?php
$page_title = 'Technology Glossary';
require_once 'includes/config.php';
require_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn about the technologies used in PlasticPollutions web application">
    <title>Technology Glossary - PlasticPollutions</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <h1 style="text-align: center; margin-bottom: 1rem; color: var(--primary-color);">Technology Glossary</h1>
            <p style="text-align: center; max-width: 800px; margin: 0 auto 3rem; color: var(--text-light);">
                Learn about the technologies and concepts used in building the PlasticPollutions web application. Click on any technology to learn more.
            </p>
            
            <!-- Frontend Technologies -->
            <div class="card" style="margin-bottom: 3rem;">
                <div class="card-header">
                    <h2><i class="fas fa-laptop-code"></i> Frontend Technologies</h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem;">
                        <div class="tech-card" onclick="showTechDetails('html5')" style="cursor: pointer; padding: 1.5rem; border: 2px solid transparent; border-radius: var(--border-radius); transition: all 0.3s;">
                            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                                <i class="fab fa-html5" style="font-size: 2rem; color: #E34C26; margin-right: 1rem;"></i>
                                <h3 style="margin: 0; color: var(--primary-color);">HTML5</h3>
                            </div>
                            <p style="color: var(--text-light); margin: 0;">The markup language for creating web pages and web applications.</p>
                        </div>
                        
                        <div class="tech-card" onclick="showTechDetails('css3')" style="cursor: pointer; padding: 1.5rem; border: 2px solid transparent; border-radius: var(--border-radius); transition: all 0.3s;">
                            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                                <i class="fab fa-css3-alt" style="font-size: 2rem; color: #1572B6; margin-right: 1rem;"></i>
                                <h3 style="margin: 0; color: var(--primary-color);">CSS3</h3>
                            </div>
                            <p style="color: var(--text-light); margin: 0;">Styling language for designing responsive and attractive web interfaces.</p>
                        </div>
                        
                        <div class="tech-card" onclick="showTechDetails('javascript')" style="cursor: pointer; padding: 1.5rem; border: 2px solid transparent; border-radius: var(--border-radius); transition: all 0.3s;">
                            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                                <i class="fab fa-js" style="font-size: 2rem; color: #F7DF1E; margin-right: 1rem;"></i>
                                <h3 style="margin: 0; color: var(--primary-color);">JavaScript</h3>
                            </div>
                            <p style="color: var(--text-light); margin: 0;">Programming language for adding interactivity and dynamic behavior to websites.</p>
                        </div>
                        
                        <div class="tech-card" onclick="showTechDetails('fontawesome')" style="cursor: pointer; padding: 1.5rem; border: 2px solid transparent; border-radius: var(--border-radius); transition: all 0.3s;">
                            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                                <i class="fab fa-font-awesome-flag" style="font-size: 2rem; color: #339AF0; margin-right: 1rem;"></i>
                                <h3 style="margin: 0; color: var(--primary-color);">Font Awesome</h3>
                            </div>
                            <p style="color: var(--text-light); margin: 0;">Icon library providing scalable vector icons for web design.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Backend Technologies -->
            <div class="card" style="margin-bottom: 3rem;">
                <div class="card-header">
                    <h2><i class="fas fa-server"></i> Backend Technologies</h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem;">
                        <div class="tech-card" onclick="showTechDetails('php')" style="cursor: pointer; padding: 1.5rem; border: 2px solid transparent; border-radius: var(--border-radius); transition: all 0.3s;">
                            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                                <i class="fab fa-php" style="font-size: 2rem; color: #777BB4; margin-right: 1rem;"></i>
                                <h3 style="margin: 0; color: var(--primary-color);">PHP</h3>
                            </div>
                            <p style="color: var(--text-light); margin: 0;">Server-side scripting language for dynamic web development.</p>
                        </div>
                        
                        <div class="tech-card" onclick="showTechDetails('mysql')" style="cursor: pointer; padding: 1.5rem; border: 2px solid transparent; border-radius: var(--border-radius); transition: all 0.3s;">
                            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                                <i class="fas fa-database" style="font-size: 2rem; color: #4479A1; margin-right: 1rem;"></i>
                                <h3 style="margin: 0; color: var(--primary-color);">MySQL</h3>
                            </div>
                            <p style="color: var(--text-light); margin: 0;">Relational database management system for storing and managing data.</p>
                        </div>
                        
                        <div class="tech-card" onclick="showTechDetails('pdo')" style="cursor: pointer; padding: 1.5rem; border: 2px solid transparent; border-radius: var(--border-radius); transition: all 0.3s;">
                            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                                <i class="fas fa-plug" style="font-size: 2rem; color: var(--primary-color); margin-right: 1rem;"></i>
                                <h3 style="margin: 0; color: var(--primary-color);">PDO</h3>
                            </div>
                            <p style="color: var(--text-light); margin: 0;">PHP Data Objects for database access with prepared statements.</p>
                        </div>
                        
                        <div class="tech-card" onclick="showTechDetails('xampp')" style="cursor: pointer; padding: 1.5rem; border: 2px solid transparent; border-radius: var(--border-radius); transition: all 0.3s;">
                            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                                <i class="fas fa-cube" style="font-size: 2rem; color: #FB7A24; margin-right: 1rem;"></i>
                                <h3 style="margin: 0; color: var(--primary-color);">XAMPP</h3>
                            </div>
                            <p style="color: var(--text-light); margin: 0;">Local development environment with Apache, MySQL, and PHP.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Security Concepts -->
            <div class="card" style="margin-bottom: 3rem;">
                <div class="card-header">
                    <h2><i class="fas fa-shield-alt"></i> Security Concepts</h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem;">
                        <div class="tech-card" onclick="showTechDetails('bcrypt')" style="cursor: pointer; padding: 1.5rem; border: 2px solid transparent; border-radius: var(--border-radius); transition: all 0.3s;">
                            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                                <i class="fas fa-lock" style="font-size: 2rem; color: var(--success); margin-right: 1rem;"></i>
                                <h3 style="margin: 0; color: var(--primary-color);">bcrypt</h3>
                            </div>
                            <p style="color: var(--text-light); margin: 0;">Password hashing algorithm for secure password storage.</p>
                        </div>
                        
                        <div class="tech-card" onclick="showTechDetails('sqlinjection')" style="cursor: pointer; padding: 1.5rem; border: 2px solid transparent; border-radius: var(--border-radius); transition: all 0.3s;">
                            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                                <i class="fas fa-exclamation-triangle" style="font-size: 2rem; color: var(--warning); margin-right: 1rem;"></i>
                                <h3 style="margin: 0; color: var(--primary-color);">SQL Injection</h3>
                            </div>
                            <p style="color: var(--text-light); margin: 0;">Common web vulnerability and how to prevent it.</p>
                        </div>
                        
                        <div class="tech-card" onclick="showTechDetails('session')" style="cursor: pointer; padding: 1.5rem; border: 2px solid transparent; border-radius: var(--border-radius); transition: all 0.3s;">
                            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                                <i class="fas fa-user-clock" style="font-size: 2rem; color: var(--info); margin-right: 1rem;"></i>
                                <h3 style="margin: 0; color: var(--primary-color);">Sessions</h3>
                            </div>
                            <p style="color: var(--text-light); margin: 0;">User authentication and state management in web applications.</p>
                        </div>
                        
                        <div class="tech-card" onclick="showTechDetails('csrf')" style="cursor: pointer; padding: 1.5rem; border: 2px solid transparent; border-radius: var(--border-radius); transition: all 0.3s;">
                            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                                <i class="fas fa-shield-virus" style="font-size: 2rem; color: var(--danger); margin-right: 1rem;"></i>
                                <h3 style="margin: 0; color: var(--primary-color);">CSRF Protection</h3>
                            </div>
                            <p style="color: var(--text-light); margin: 0;">Cross-Site Request Forgery prevention techniques.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Development Concepts -->
            <div class="card" style="margin-bottom: 3rem;">
                <div class="card-header">
                    <h2><i class="fas fa-code"></i> Development Concepts</h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem;">
                        <div class="tech-card" onclick="showTechDetails('responsive')" style="cursor: pointer; padding: 1.5rem; border: 2px solid transparent; border-radius: var(--border-radius); transition: all 0.3s;">
                            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                                <i class="fas fa-mobile-alt" style="font-size: 2rem; color: var(--primary-color); margin-right: 1rem;"></i>
                                <h3 style="margin: 0; color: var(--primary-color);">Responsive Design</h3>
                            </div>
                            <p style="color: var(--text-light); margin: 0;">Creating websites that work on all device sizes.</p>
                        </div>
                        
                        <div class="tech-card" onclick="showTechDetails('mvc')" style="cursor: pointer; padding: 1.5rem; border: 2px solid transparent; border-radius: var(--border-radius); transition: all 0.3s;">
                            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                                <i class="fas fa-project-diagram" style="font-size: 2rem; color: var(--primary-color); margin-right: 1rem;"></i>
                                <h3 style="margin: 0; color: var(--primary-color);">MVC Pattern</h3>
                            </div>
                            <p style="color: var(--text-light); margin: 0;">Model-View-Controller architecture for web applications.</p>
                        </div>
                        
                        <div class="tech-card" onclick="showTechDetails('api')" style="cursor: pointer; padding: 1.5rem; border: 2px solid transparent; border-radius: var(--border-radius); transition: all 0.3s;">
                            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                                <i class="fas fa-plug" style="font-size: 2rem; color: var(--primary-color); margin-right: 1rem;"></i>
                                <h3 style="margin: 0; color: var(--primary-color);">API</h3>
                            </div>
                            <p style="color: var(--text-light); margin: 0;">Application Programming Interface concepts.</p>
                        </div>
                        
                        <div class="tech-card" onclick="showTechDetails('ajax')" style="cursor: pointer; padding: 1.5rem; border: 2px solid transparent; border-radius: var(--border-radius); transition: all 0.3s;">
                            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                                <i class="fas fa-sync-alt" style="font-size: 2rem; color: var(--primary-color); margin-right: 1rem;"></i>
                                <h3 style="margin: 0; color: var(--primary-color);">AJAX</h3>
                            </div>
                            <p style="color: var(--text-light); margin: 0;">Asynchronous JavaScript for dynamic web interactions.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Technology Details Modal -->
    <div id="techModal" class="modal" style="display: none;">
        <div class="modal-content" style="max-width: 600px; margin: 2rem auto;">
            <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; padding: 1rem; border-bottom: 1px solid #ddd;">
                <h2 id="modalTitle" style="margin: 0; color: var(--primary-color);"></h2>
                <button onclick="closeTechModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">&times;</button>
            </div>
            <div class="modal-body" style="padding: 1.5rem;">
                <div id="modalContent"></div>
            </div>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    
    <style>
        .tech-card:hover {
            border-color: var(--primary-color) !important;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .modal {
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            max-height: 80vh;
            overflow-y: auto;
        }
    </style>
    
    <script>
        const techDetails = {
            'html5': {
                title: 'HTML5',
                icon: 'fab fa-html5',
                color: '#E34C26',
                description: 'HTML5 (HyperText Markup Language 5) is the latest version of the standard markup language for creating web pages and web applications.',
                features: [
                    'Semantic elements like <header>, <nav>, <article>, <section>',
                    'Multimedia support with <video> and <audio> tags',
                    'Canvas and SVG for graphics',
                    'Form validation and input types',
                    'Local storage and session storage',
                    'Geolocation API',
                    'Responsive images and picture elements'
                ],
                usage: 'Used for structuring the content of all web pages in this application',
                examples: 'Page structure, forms, semantic content organization'
            },
            'css3': {
                title: 'CSS3',
                icon: 'fab fa-css3-alt',
                color: '#1572B6',
                description: 'CSS3 (Cascading Style Sheets 3) is the latest evolution of the CSS language, designed to style and layout web pages.',
                features: [
                    'Flexbox and Grid layouts',
                    'CSS Variables (Custom Properties)',
                    'Animations and transitions',
                    'Media queries for responsive design',
                    'Transforms and filters',
                    'Pseudo-elements and pseudo-classes',
                    'Box-sizing and border-radius'
                ],
                usage: 'Used for all visual styling, responsive design, and animations in this application',
                examples: 'Responsive layouts, color schemes, animations, hover effects'
            },
            'javascript': {
                title: 'JavaScript',
                icon: 'fab fa-js',
                color: '#F7DF1E',
                description: 'JavaScript is a high-level, interpreted programming language that enables interactive web pages and is an essential part of web applications.',
                features: [
                    'ES6+ features (arrow functions, destructuring, classes)',
                    'DOM manipulation and event handling',
                    'AJAX and Fetch API for server communication',
                    'Local storage and session management',
                    'Form validation and user interactions',
                    'Dynamic content updates',
                    'Error handling and debugging'
                ],
                usage: 'Used for all interactive features, form validation, sliders, and dynamic content',
                examples: 'Image slider, form validation, modal windows, dynamic counters'
            },
            'php': {
                title: 'PHP',
                icon: 'fab fa-php',
                color: '#777BB4',
                description: 'PHP (Hypertext Preprocessor) is a server-side scripting language designed for web development but also used as a general-purpose programming language.',
                features: [
                    'Server-side processing and database integration',
                    'Session management and authentication',
                    'Form processing and validation',
                    'File handling and uploads',
                    'Database connectivity with PDO',
                    'Security functions and filtering',
                    'Error handling and logging',
                    'Object-oriented programming support'
                ],
                usage: 'Used for all backend logic, database operations, user authentication, and content management',
                examples: 'User registration/login, blog management, donation processing, admin panel'
            },
            'mysql': {
                title: 'MySQL',
                icon: 'fas fa-database',
                color: '#4479A1',
                description: 'MySQL is an open-source relational database management system (RDBMS) that uses SQL for adding, accessing, and managing data in a database.',
                features: [
                    'Relational database with tables and relationships',
                    'SQL query language',
                    'ACID compliance for data integrity',
                    'Indexing for performance optimization',
                    'Foreign keys and constraints',
                    'Stored procedures and triggers',
                    'User permissions and security',
                    'Backup and replication features'
                ],
                usage: 'Stores all application data including users, donations, blog posts, and campaign information',
                examples: 'User accounts, donation records, blog content, petition signatures'
            },
            'pdo': {
                title: 'PDO (PHP Data Objects)',
                icon: 'fas fa-plug',
                color: 'var(--primary-color)',
                description: 'PDO is a database access layer providing a uniform method of access to multiple databases in PHP.',
                features: [
                    'Prepared statements for security',
                    'Named placeholders and parameter binding',
                    'Error handling with exceptions',
                    'Support for multiple database drivers',
                    'Transaction management',
                    'Fetch styles and methods',
                    'Connection management',
                    'SQL injection prevention'
                ],
                usage: 'Provides secure database connectivity between PHP and MySQL',
                examples: 'All database queries, user authentication, data retrieval and storage'
            },
            'bcrypt': {
                title: 'bcrypt Password Hashing',
                icon: 'fas fa-lock',
                color: 'var(--success)',
                description: 'bcrypt is a password hashing function designed to be slow and computationally expensive, making it resistant to brute-force attacks.',
                features: [
                    'Adaptive hash function with cost factor',
                    'Built-in salt generation',
                    'Resistance to rainbow table attacks',
                    'Slow hashing for security',
                    'Cross-platform compatibility',
                    'Widely supported security standard',
                    'Automatic salt management',
                    'Future-proof against hardware improvements'
                ],
                usage: 'Used for securely hashing all user passwords in the database',
                examples: 'User registration, password changes, authentication verification'
            },
            'responsive': {
                title: 'Responsive Web Design',
                icon: 'fas fa-mobile-alt',
                color: 'var(--primary-color)',
                description: 'Responsive web design is an approach that makes web pages render well on a variety of devices and window sizes.',
                features: [
                    'Flexible grids and layouts',
                    'Flexible images and media',
                    'Media queries for breakpoints',
                    'Mobile-first design approach',
                    'Touch-friendly interfaces',
                    'Viewport optimization',
                    'Performance optimization',
                    'Progressive enhancement'
                ],
                usage: 'Ensures the application works properly on desktop, tablet, and mobile devices',
                examples: 'Navigation menus, card layouts, image sizing, typography scaling'
            },
            'sqlinjection': {
                title: 'SQL Injection Prevention',
                icon: 'fas fa-exclamation-triangle',
                color: 'var(--warning)',
                description: 'SQL injection is a code injection technique that might destroy your database. We prevent it using prepared statements.',
                features: [
                    'Prepared statements with parameter binding',
                    'Input validation and sanitization',
                    'Least privilege database access',
                    'Error message handling',
                    'Regular expression validation',
                    'Type checking',
                    'Length limitations',
                    'Whitelist validation'
                ],
                usage: 'Security measure to protect database from malicious SQL injection attacks',
                examples: 'All database queries, form inputs, search functionality'
            },
            'session': {
                title: 'Session Management',
                icon: 'fas fa-user-clock',
                color: 'var(--info)',
                description: 'Sessions provide a way to store information across multiple pages for a particular user, enabling stateful web applications.',
                features: [
                    'User authentication and authorization',
                    'Session timeout and expiration',
                    'Secure session cookie handling',
                    'Session fixation prevention',
                    'Cross-site scripting protection',
                    'Session hijacking prevention',
                    'User state management',
                    'Multi-device session handling'
                ],
                usage: 'Manages user login state, shopping carts, and personalized content',
                examples: 'User login persistence, shopping cart, user preferences, access control'
            },
            'fontawesome': {
                title: 'Font Awesome',
                icon: 'fab fa-font-awesome-flag',
                color: '#339AF0',
                description: 'Font Awesome is a font and icon toolkit based on CSS and LESS, providing scalable vector icons that can be customized with CSS.',
                features: [
                    'Scalable vector icons',
                    'CSS styling control',
                    'Large icon library',
                    'Multiple icon styles',
                    'Accessibility features',
                    'Screen reader support',
                    'Custom animations',
                    'Brand and social icons'
                ],
                usage: 'Used throughout the application for icons in navigation, buttons, and visual elements',
                examples: 'Navigation icons, social media buttons, form icons, status indicators'
            },
            'xampp': {
                title: 'XAMPP',
                icon: 'fas fa-cube',
                color: '#FB7A24',
                description: 'XAMPP is a free and open-source cross-platform web server solution stack package consisting of Apache, MariaDB, PHP, and Perl.',
                features: [
                    'Apache web server',
                    'MySQL/MariaDB database',
                    'PHP interpreter',
                    'phpMyAdmin database tool',
                    'FileZilla FTP server',
                    'Mercury mail server',
                    'Tomcat servlet container',
                    'Local development environment'
                ],
                usage: 'Provides the complete local development environment for this project',
                examples: 'Local testing, database management, file serving, PHP execution'
            },
            'mvc': {
                title: 'MVC (Model-View-Controller)',
                icon: 'fas fa-project-diagram',
                color: 'var(--primary-color)',
                description: 'MVC is a software architectural pattern for implementing user interfaces by separating an application into three interconnected parts.',
                features: [
                    'Model: Data and business logic',
                    'View: User interface and presentation',
                    'Controller: Handles user input and coordinates',
                    'Separation of concerns',
                    'Code reusability',
                    'Parallel development',
                    'Easier maintenance',
                    'Testability improvements'
                ],
                usage: 'Architectural pattern used for organizing code structure in this application',
                examples: 'Database models (Model), HTML templates (View), PHP controllers (Controller)'
            },
            'api': {
                title: 'API (Application Programming Interface)',
                icon: 'fas fa-plug',
                color: 'var(--primary-color)',
                description: 'An API is a set of definitions and protocols for building and integrating application software, enabling communication between different services.',
                features: [
                    'RESTful design principles',
                    'HTTP methods (GET, POST, PUT, DELETE)',
                    'JSON data format',
                    'Authentication and authorization',
                    'Rate limiting',
                    'Error handling',
                    'Documentation',
                    'Versioning'
                ],
                usage: 'Defines how different parts of the application communicate and exchange data',
                examples: 'Database operations, form submissions, AJAX requests, data retrieval'
            },
            'csrf': {
                title: 'CSRF Protection',
                icon: 'fas fa-shield-virus',
                color: 'var(--danger)',
                description: 'Cross-Site Request Forgery (CSRF) is an attack that forces authenticated users to submit unwanted requests to a web application.',
                features: [
                    'CSRF tokens',
                    'SameSite cookie attributes',
                    'Origin validation',
                    'Referer checking',
                    'Double submit cookies',
                    'Custom headers',
                    'Synchronizer token pattern',
                    'State-changing request validation'
                ],
                usage: 'Security measure to protect against CSRF attacks on form submissions',
                examples: 'All forms, AJAX requests, state-changing operations'
            },
            'ajax': {
                title: 'AJAX (Asynchronous JavaScript)',
                icon: 'fas fa-sync-alt',
                color: 'var(--primary-color)',
                description: 'AJAX is a set of web development techniques using many web technologies on the client-side to create asynchronous web applications.',
                features: [
                    'Asynchronous data transfer',
                    'Dynamic content updates',
                    'Improved user experience',
                    'Reduced page reloads',
                    'Background processing',
                    'Real-time updates',
                    'Fetch API integration',
                    'Error handling and retry logic'
                ],
                usage: 'Enables dynamic interactions without page reloads for better user experience',
                examples: 'Form validation, live search, notifications, dashboard updates'
            }
        };
        
        function showTechDetails(tech) {
            const details = techDetails[tech];
            if (!details) return;
            
            const modal = document.getElementById('techModal');
            const modalTitle = document.getElementById('modalTitle');
            const modalContent = document.getElementById('modalContent');
            
            modalTitle.innerHTML = `<i class="${details.icon}" style="color: ${details.color}; margin-right: 0.5rem;"></i> ${details.title}`;
            
            modalContent.innerHTML = `
                <div style="margin-bottom: 1.5rem;">
                    <p style="line-height: 1.6; color: var(--text-light);">${details.description}</p>
                </div>
                
                <div style="margin-bottom: 1.5rem;">
                    <h4 style="color: var(--primary-color); margin-bottom: 1rem;">Key Features:</h4>
                    <ul style="line-height: 1.8; color: var(--text-light);">
                        ${details.features.map(feature => `<li>${feature}</li>`).join('')}
                    </ul>
                </div>
                
                <div style="margin-bottom: 1.5rem;">
                    <h4 style="color: var(--primary-color); margin-bottom: 0.5rem;">Usage in This Project:</h4>
                    <p style="color: var(--text-light);">${details.usage}</p>
                </div>
                
                <div>
                    <h4 style="color: var(--primary-color); margin-bottom: 0.5rem;">Examples:</h4>
                    <p style="color: var(--text-light);">${details.examples}</p>
                </div>
            `;
            
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        function closeTechModal() {
            const modal = document.getElementById('techModal');
            modal.style.display = 'none';
            document.body.style.overflow = '';
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('techModal');
            if (event.target == modal) {
                closeTechModal();
            }
        }
        
        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeTechModal();
            }
        });
    </script>
</body>
</html>
