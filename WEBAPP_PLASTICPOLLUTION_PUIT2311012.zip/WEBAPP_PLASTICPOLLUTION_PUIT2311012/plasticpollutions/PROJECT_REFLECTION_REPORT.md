 PROJECT REFLECTION REPORT.

 WHAT I LEARNED

Developing the PlasticPollutions web application has been an invaluable learning experience that significantly enhanced my understanding of full-stack web development. Throughout this project, I gained practical knowledge in PHP server-side programming, MySQL database design and management, and JavaScript for client-side interactivity. I learned how to implement secure authentication systems using bcrypt password hashing, session management, and input sanitization to prevent SQL injection attacks. The project also taught me the importance of responsive web design using CSS Grid and Flexbox to ensure accessibility across different devices. I developed skills in creating modular, reusable code through PHP includes and functions, which improved code maintainability and organization.

CHALLENGES ENCOUNTERED 

Several challenges emerged during the development process. The most significant was implementing the login lockout mechanism after three failed attempts. Initially, I struggled with tracking login attempts and managing the timing for lockout expiration. I resolved this by creating a dedicated login_attempts table and implementing time-based checks using PHP's strtotime function. Another challenge was ensuring the visitor ID generator produced unique identifiers with the required "PU" prefix followed by six digits. I overcame this by implementing a loop with regex validation and database uniqueness checks. Managing file uploads for blog post images also presented security concerns, which I addressed by implementing strict file type validation, size limits, and secure file naming using uniqid().

SOLUTIONS IMPLEMENTED 

To address these challenges, I adopted a systematic approach. For the login lockout system, I created a comprehensive tracking mechanism that records failed attempts, stores lockout timestamps, and automatically unlocks accounts after the specified period. The visitor ID generator uses a retry mechanism with a maximum attempt limit to prevent infinite loops while ensuring uniqueness. I implemented prepared statements throughout the application to prevent SQL injection, and used PDO for secure database connections. For file uploads, I created a dedicated upload function that validates file types, checks file sizes, and generates secure filenames.

 AREAS OF IMPROVEMENT

The system could be improved in several areas. Accessibility could be enhanced by adding ARIA labels throughout the application, implementing keyboard navigation for all interactive elements, and providing alt text for all images. Performance could be improved by implementing database indexing on frequently queried columns, adding caching mechanisms for static content, and optimizing image loading through lazy loading. Scalability could be enhanced by implementing a content delivery network (CDN) for static assets, adding database connection pooling, and implementing API endpoints for mobile applications. The admin panel could benefit from more advanced features such as bulk operations, advanced search and filtering, and data export capabilities. Additionally, implementing real-time notifications using WebSockets would improve user engagement, and adding automated email notifications for important events would enhance the user experience.

 CONCLUSION

This project has been instrumental in developing my technical skills and understanding of web application development best practices. The experience of building a complete, functional web application from scratch has provided me with practical knowledge that extends beyond theoretical concepts. The challenges encountered and resolved have strengthened my problem-solving abilities and taught me the importance of thorough testing and security considerations in web development.
