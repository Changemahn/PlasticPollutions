<?php
$page_title = 'Home';
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Get statistics for counters
$pdo = db();
$visitor_count = get_visitor_count();
$total_donations = get_total_donations();
$petitions_signed = $pdo->query("SELECT COUNT(*) as count FROM petition_signatures")->fetch()['count'] ?? 0;
$blog_posts = $pdo->query("SELECT COUNT(*) as count FROM blog_posts WHERE is_published = 1")->fetch()['count'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="PlasticPollutions - Pentecost University's environmental action group fighting plastic pollution">
    <title>Home - PlasticPollutions</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1>Fighting Plastic Pollution Together</h1>
            <p>Join PlasticPollutions at Pentecost University in our mission to reduce plastic waste, protect our oceans, and create a sustainable future for generations to come.</p>
            <div class="hero-buttons">
                <button class="btn btn-primary" id="openSignupModal">Sign Up Now</button>
                <a href="help.php" class="btn btn-outline" style="color: white; border-color: white;">How You Can Help</a>
            </div>
            
            <div class="hero-stats">
                <div class="stat-item">
                    <div class="stat-number" data-target="<?php echo $visitor_count; ?>">0</div>
                    <div class="stat-label">Visitors</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number" data-target="<?php echo number_format($total_donations); ?>">0</div>
                    <div class="stat-label">Donations (GHS)</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number" data-target="<?php echo $petitions_signed; ?>">0</div>
                    <div class="stat-label">Petitions Signed</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number" data-target="<?php echo $blog_posts; ?>">0</div>
                    <div class="stat-label">Articles Published</div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Image Slider -->
    <section class="slider-section">
        <div class="container">
            <div class="slider" id="imageSlider">
                <div class="slider-container">
                    <div class="slide">
                        <img src="images/ocean.jpg" alt="Ocean conservation efforts">
                        <div class="slide-content">
                            <h2>Protecting Our Oceans</h2>
                            <p>Every piece of plastic removed from our oceans makes a difference.</p>
                        </div>
                    </div>
                    <div class="slide">
                        <img src="images/recycle.jpg" alt="Plastic recycling">
                        <div class="slide-content">
                            <h2>Recycling Matters</h2>
                            <p>Less than 5% of plastic waste is recycled. We're working to change that.</p>
                        </div>
                    </div>
                    <div class="slide">
                        <img src="images/life.jpg" alt="Wildlife protection">
                        <div class="slide-content">
                            <h2>Protecting Wildlife</h2>
                            <p>Plastic pollution threatens millions of marine animals every year.</p>
                        </div>
                    </div>
                    <div class="slide">
                        <img src="images/comm.jpg" alt="Community cleanup">
                        <div class="slide-content">
                            <h2>Community Action</h2>
                            <p>Join our cleanup events and make a real impact in your community.</p>
                        </div>
                    </div>
                </div>
                <button class="slider-nav slider-prev" id="prevSlide" aria-label="Previous slide">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <button class="slider-nav slider-next" id="nextSlide" aria-label="Next slide">
                    <i class="fas fa-chevron-right"></i>
                </button>
                <div class="slider-dots" id="sliderDots"></div>
            </div>
        </div>
    </section>
    
    <!-- About Section -->
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <div class="card">
                <div class="card-body">
                    <h2 style="text-align: center; margin-bottom: 1.5rem; color: var(--primary-color);">About PlasticPollutions</h2>
                    <p style="text-align: center; max-width: 800px; margin: 0 auto; line-height: 1.8;">
                        PlasticPollutions is an environmental action group at Pentecost University whose aim is to reduce plastic waste and prevent harm to oceans, wildlife, and the general environment. The group actively promotes sustainable practices and encourages individuals, manufacturers, and retailers to reduce the use of non-essential single-use plastics.
                    </p>
                    <p style="text-align: center; max-width: 800px; margin: 1.5rem auto 0; line-height: 1.8;">
                        The formation of this group was influenced by growing concerns about the large volumes of plastic waste that enter water bodies, especially during periods of heavy rainfall. Reports indicate that only a very small percentage, often less than 5%, of plastic waste is recycled, while the rest contributes significantly to environmental pollution.
                    </p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Latest News Preview -->
    <section class="section" style="padding: 4rem 0; background: var(--bg-light);">
        <div class="container">
            <h2 style="text-align: center; margin-bottom: 2rem; color: var(--primary-color);">Latest Updates</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem;">
                <?php
                $stmt = $pdo->query("SELECT * FROM blog_posts WHERE is_published = 1 ORDER BY created_at DESC LIMIT 3");
                $posts = $stmt->fetchAll();
                
                if (empty($posts)):
                ?>
                    <p style="text-align: center; grid-column: 1/-1;">No recent updates available.</p>
                <?php else: ?>
                    <?php foreach ($posts as $post): ?>
                    <div class="card">
                        <?php if ($post['featured_image']): ?>
                        <img src="<?php echo htmlspecialchars($post['featured_image']); ?>" alt="<?php echo htmlspecialchars($post['title']); ?>" style="width: 100%; height: 200px; object-fit: cover;">
                        <?php endif; ?>
                        <div class="card-body">
                            <span style="background: var(--primary-color); color: white; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.8rem;">
                                <?php echo htmlspecialchars($post['category'] ?? 'News'); ?>
                            </span>
                            <h3 style="margin: 1rem 0 0.5rem;"><?php echo htmlspecialchars($post['title']); ?></h3>
                            <p style="color: var(--text-light); margin-bottom: 1rem;">
                                <?php echo substr(strip_tags($post['content']), 0, 150); ?>...
                            </p>
                            <a href="latest.php" class="btn btn-outline">Read More</a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <div style="text-align: center; margin-top: 2rem;">
                <a href="latest.php" class="btn btn-primary">View All News</a>
            </div>
        </div>
    </section>
    
    <!-- Twitter Feed Section -->
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem;">
                <div>
                    <h2 style="margin-bottom: 1.5rem; color: var(--primary-color);">Our Mission</h2>
                    <ul style="list-style: none; line-height: 2;">
                        <li><i class="fas fa-check-circle" style="color: var(--primary-color);"></i> Raise awareness about plastic pollution</li>
                        <li><i class="fas fa-check-circle" style="color: var(--primary-color);"></i> Promote recycling and sustainable practices</li>
                        <li><i class="fas fa-check-circle" style="color: var(--primary-color);"></i> Organize cleanup campaigns</li>
                        <li><i class="fas fa-check-circle" style="color: var(--primary-color);"></i> Advocate for policy changes</li>
                        <li><i class="fas fa-check-circle" style="color: var(--primary-color);"></i> Support environmental education</li>
                    </ul>
                </div>
                <div>
                    <h2 style="margin-bottom: 1.5rem; color: var(--primary-color);">
                        <i class="fab fa-twitter"></i> Latest Tweets
                    </h2>
                    <div class="twitter-feed">
                        <div class="tweet">
                            <div class="tweet-header">
                                <div class="tweet-avatar">PP</div>
                                <div>
                                    <div class="tweet-name">PlasticPollutions</div>
                                    <div class="tweet-handle">@PlasticPollutionsGH</div>
                                </div>
                            </div>
                            <div class="tweet-content">
                                Join us this Saturday for our beach cleanup event at Labadi Beach! Together we can make a difference. 🌊♻️ #PlasticFreeGhana
                            </div>
                            <div class="tweet-time">2 hours ago</div>
                        </div>
                        <div class="tweet">
                            <div class="tweet-header">
                                <div class="tweet-avatar">PP</div>
                                <div>
                                    <div class="tweet-name">PlasticPollutions</div>
                                    <div class="tweet-handle">@PlasticPollutionsGH</div>
                                </div>
                            </div>
                            <div class="tweet-content">
                                Did you know? Over 8 million tons of plastic enter our oceans every year. Let's reduce our plastic footprint! 🌍💚
                            </div>
                            <div class="tweet-time">5 hours ago</div>
                        </div>
                        <div class="tweet">
                            <div class="tweet-header">
                                <div class="tweet-avatar">PP</div>
                                <div>
                                    <div class="tweet-name">PlasticPollutions</div>
                                    <div class="tweet-handle">@PlasticPollutionsGH</div>
                                </div>
                            </div>
                            <div class="tweet-content">
                                Thank you to all our volunteers who helped collect 500kg of plastic waste last weekend! Your dedication inspires us. 🙏
                            </div>
                            <div class="tweet-time">1 day ago</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Call to Action -->
    <section class="section" style="padding: 4rem 0; background: var(--primary-dark); color: white;">
        <div class="container" style="text-align: center;">
            <h2 style="margin-bottom: 1rem;">Ready to Make a Difference?</h2>
            <p style="margin-bottom: 2rem; opacity: 0.9;">Join thousands of Ghanaians committed to reducing plastic pollution</p>
            <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                <button class="btn btn-primary" id="openSignupModal2" style="background: white; color: var(--primary-dark);">Sign Up Now</button>
                <a href="donate.php" class="btn btn-outline" style="color: white; border-color: white;">Donate</a>
                <a href="help.php" class="btn btn-outline" style="color: white; border-color: white;">Volunteer</a>
            </div>
        </div>
    </section>
    
    <!-- Sign Up Modal -->
    <div class="modal" id="signupModal" role="dialog" aria-labelledby="signupModalTitle">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="signupModalTitle">Sign Up Now</h2>
                <button class="modal-close" id="closeSignupModal" aria-label="Close modal">&times;</button>
            </div>
            <div class="modal-body">
                <p style="margin-bottom: 1.5rem;">Join our community and help make a difference in the fight against plastic pollution.</p>
                <form id="signupForm" action="register.php" method="POST">
                    <div class="form-group">
                        <label for="modal_first_name">First Name *</label>
                        <input type="text" id="modal_first_name" name="first_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="modal_last_name">Last Name *</label>
                        <input type="text" id="modal_last_name" name="last_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="modal_email">Email Address *</label>
                        <input type="email" id="modal_email" name="email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="modal_password">Password *</label>
                        <input type="password" id="modal_password" name="password" class="form-control" required>
                        <small class="form-text">Minimum 8 characters with uppercase, lowercase, number, and special character</small>
                    </div>
                    <div class="form-group">
                        <label for="modal_confirm_password">Confirm Password *</label>
                        <input type="password" id="modal_confirm_password" name="confirm_password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Create Account</button>
                </form>
            </div>
            <div class="modal-footer">
                <span style="margin-right: auto;">Already have an account?</span>
                <a href="login.php" class="btn btn-outline">Login</a>
            </div>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    <script src="js/home.js"></script>
</body>
</html>
