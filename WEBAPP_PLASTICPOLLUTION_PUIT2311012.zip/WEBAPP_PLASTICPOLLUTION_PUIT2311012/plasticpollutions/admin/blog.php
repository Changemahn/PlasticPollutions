<?php
$page_title = 'Blog Management';
require_once '../includes/config.php';
require_once '../includes/functions.php';

require_admin();

$pdo = db();
$errors = [];
$success = false;

// Handle blog post actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add_post' || $action === 'edit_post') {
        $title = sanitize_input($_POST['title'] ?? '');
        $content = $_POST['content'] ?? '';
        $excerpt = sanitize_input($_POST['excerpt'] ?? '');
        $category = sanitize_input($_POST['category'] ?? 'News');
        $is_published = isset($_POST['is_published']) ? 1 : 0;
        
        if (empty($title) || empty($content)) {
            $errors[] = "Title and content are required";
        }
        
        if (empty($errors)) {
            try {
                if ($action === 'add_post') {
                    $slug = strtolower(preg_replace('/[^a-z0-9]+/', '-', $title));
                    $slug = trim($slug, '-');
                    
                    $stmt = $pdo->prepare("INSERT INTO blog_posts (title, slug, content, excerpt, category, author_id, is_published) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$title, $slug, $content, $excerpt, $category, $_SESSION['user_id'], $is_published]);
                    $success = true;
                    set_flash_message('success', 'Blog post created successfully');
                } else {
                    $post_id = intval($_POST['post_id'] ?? 0);
                    $stmt = $pdo->prepare("UPDATE blog_posts SET title = ?, content = ?, excerpt = ?, category = ?, is_published = ? WHERE id = ?");
                    $stmt->execute([$title, $content, $excerpt, $category, $is_published, $post_id]);
                    $success = true;
                    set_flash_message('success', 'Blog post updated successfully');
                }
            } catch (Exception $e) {
                $errors[] = "Failed to save post: " . $e->getMessage();
            }
        }
    } elseif ($action === 'delete_post') {
        $post_id = intval($_POST['post_id'] ?? 0);
        try {
            $stmt = $pdo->prepare("DELETE FROM blog_posts WHERE id = ?");
            $stmt->execute([$post_id]);
            $success = true;
            set_flash_message('success', 'Blog post deleted successfully');
        } catch (Exception $e) {
            $errors[] = "Failed to delete post: " . $e->getMessage();
        }
    }
}

// Get all blog posts
$posts = $pdo->query("SELECT * FROM blog_posts ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Management - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <div class="dashboard-header">
                <div>
                    <h1 style="color: var(--primary-color);">Blog Management</h1>
                    <p style="color: var(--text-light);">Create and manage blog posts</p>
                </div>
                <a href="dashboard.php" class="btn btn-outline">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
            
            <?php if (has_flash_message('success')): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars(get_flash_message('success')); ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error): ?>
                        <p><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <!-- Add New Post Form -->
            <div class="card" style="margin-bottom: 2rem;">
                <div class="card-header">
                    <h2>Create New Post</h2>
                </div>
                <div class="card-body">
                    <form method="POST" action="blog.php">
                        <input type="hidden" name="action" value="add_post">
                        
                        <div class="form-group">
                            <label for="title">Title *</label>
                            <input type="text" id="title" name="title" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="category">Category</label>
                            <select id="category" name="category" class="form-control">
                                <option value="News">News</option>
                                <option value="Environment">Environment</option>
                                <option value="Education">Education</option>
                                <option value="Events">Events</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="excerpt">Excerpt</label>
                            <textarea id="excerpt" name="excerpt" class="form-control" rows="2" placeholder="Brief summary of the post..."></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="content">Content *</label>
                            <textarea id="content" name="content" class="form-control" rows="10" required></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label class="checkbox-label">
                                <input type="checkbox" name="is_published"> Publish immediately
                            </label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Create Post</button>
                    </form>
                </div>
            </div>
            
            <!-- Existing Posts -->
            <div class="card">
                <div class="card-header">
                    <h2>Existing Posts</h2>
                </div>
                <div class="card-body">
                    <div style="overflow-x: auto;">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Category</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($posts as $post): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($post['title']); ?></td>
                                    <td><?php echo htmlspecialchars($post['category']); ?></td>
                                    <td>
                                        <span style="color: <?php echo $post['is_published'] ? 'var(--success)' : 'var(--warning)'; ?>;">
                                            <?php echo $post['is_published'] ? 'Published' : 'Draft'; ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($post['created_at'])); ?></td>
                                    <td>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this post?');">
                                            <input type="hidden" name="action" value="delete_post">
                                            <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                                            <button type="submit" class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.875rem;">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
