<?php
$page_title = 'Campaign Management';
require_once '../includes/config.php';
require_once '../includes/functions.php';

require_admin();

$pdo = db();
$errors = [];
$success = false;

// Handle campaign actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add_campaign') {
        $title = sanitize_input($_POST['title'] ?? '');
        $description = $_POST['description'] ?? '';
        $goal = sanitize_input($_POST['goal'] ?? '');
        $start_date = $_POST['start_date'] ?? '';
        $end_date = $_POST['end_date'] ?? '';
        $status = sanitize_input($_POST['status'] ?? 'planning');
        
        if (empty($title) || empty($description)) {
            $errors[] = "Title and description are required";
        }
        
        if (empty($errors)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO campaigns (title, description, goal, start_date, end_date, status) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $description, $goal, $start_date, $end_date, $status]);
                $success = true;
                set_flash_message('success', 'Campaign created successfully');
            } catch (Exception $e) {
                $errors[] = "Failed to create campaign: " . $e->getMessage();
            }
        }
    } elseif ($action === 'delete_campaign') {
        $campaign_id = intval($_POST['campaign_id'] ?? 0);
        try {
            $stmt = $pdo->prepare("DELETE FROM campaigns WHERE id = ?");
            $stmt->execute([$campaign_id]);
            $success = true;
            set_flash_message('success', 'Campaign deleted successfully');
        } catch (Exception $e) {
            $errors[] = "Failed to delete campaign: " . $e->getMessage();
        }
    }
}

// Get all campaigns
$campaigns = $pdo->query("SELECT * FROM campaigns ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campaign Management - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <div class="dashboard-header">
                <div>
                    <h1 style="color: var(--primary-color);">Campaign Management</h1>
                    <p style="color: var(--text-light);">Manage environmental campaigns</p>
                </div>
                <a href="dashboard.php" class="btn btn-outline">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
            
            <?php if (has_flash_message('success')): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars(get_flash_message('success')); ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error): ?>
                        <p><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <!-- Add Campaign Form -->
            <div class="card" style="margin-bottom: 2rem;">
                <div class="card-header">
                    <h2>Create New Campaign</h2>
                </div>
                <div class="card-body">
                    <form method="POST" action="campaigns.php">
                        <input type="hidden" name="action" value="add_campaign">
                        
                        <div class="form-group">
                            <label for="title">Campaign Title *</label>
                            <input type="text" id="title" name="title" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="description">Description *</label>
                            <textarea id="description" name="description" class="form-control" rows="4" required></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="goal">Goal</label>
                            <input type="text" id="goal" name="goal" class="form-control" placeholder="e.g., Remove 100 tons of plastic">
                        </div>
                        
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                            <div class="form-group">
                                <label for="start_date">Start Date</label>
                                <input type="date" id="start_date" name="start_date" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="end_date">End Date</label>
                                <input type="date" id="end_date" name="end_date" class="form-control">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select id="status" name="status" class="form-control">
                                <option value="planning">Planning</option>
                                <option value="active">Active</option>
                                <option value="completed">Completed</option>
                                <option value="cancelled">Cancelled</option>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Create Campaign</button>
                    </form>
                </div>
            </div>
            
            <!-- Existing Campaigns -->
            <div class="card">
                <div class="card-header">
                    <h2>Existing Campaigns</h2>
                </div>
                <div class="card-body">
                    <?php if (empty($campaigns)): ?>
                        <p style="text-align: center; padding: 2rem; color: var(--text-light);">No campaigns yet.</p>
                    <?php else: ?>
                        <div style="overflow-x: auto;">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Goal</th>
                                        <th>Status</th>
                                        <th>Duration</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($campaigns as $campaign): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($campaign['title']); ?></td>
                                        <td><?php echo htmlspecialchars($campaign['goal']); ?></td>
                                        <td>
                                            <span style="padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.875rem; background: <?php 
                                                echo match($campaign['status']) {
                                                    'active' => 'var(--success)',
                                                    'completed' => 'var(--primary-color)',
                                                    'planning' => 'var(--warning)',
                                                    'cancelled' => 'var(--danger)',
                                                    default => 'var(--text-light)'
                                                };
                                            ?>; color: white;">
                                                <?php echo ucfirst($campaign['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php 
                                            if ($campaign['start_date']) echo date('M d, Y', strtotime($campaign['start_date']));
                                            if ($campaign['start_date'] && $campaign['end_date']) echo ' - ';
                                            if ($campaign['end_date']) echo date('M d, Y', strtotime($campaign['end_date']));
                                            ?>
                                        </td>
                                        <td>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this campaign?');">
                                                <input type="hidden" name="action" value="delete_campaign">
                                                <input type="hidden" name="campaign_id" value="<?php echo $campaign['id']; ?>">
                                                <button type="submit" class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.875rem;">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
