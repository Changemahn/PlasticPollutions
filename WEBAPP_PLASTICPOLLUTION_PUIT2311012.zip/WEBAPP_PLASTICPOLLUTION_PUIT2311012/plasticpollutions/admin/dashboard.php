<?php
$page_title = 'Admin Dashboard';
require_once '../includes/config.php';
require_once '../includes/functions.php';

require_admin();

$pdo = db();

// Get statistics
$total_users = $pdo->query("SELECT COUNT(*) as count FROM users")->fetch()['count'];
$total_donations = get_total_donations();
$total_messages = $pdo->query("SELECT COUNT(*) as count FROM contact_messages WHERE is_read = 0")->fetch()['count'];
$total_posts = $pdo->query("SELECT COUNT(*) as count FROM blog_posts")->fetch()['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - PlasticPollutions</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <div class="dashboard-header">
                <div>
                    <h1 style="color: var(--primary-color);">Admin Dashboard</h1>
                    <p style="color: var(--text-light);">Manage your website content and users</p>
                </div>
                <div>
                    <a href="../dashboard.php" class="btn btn-outline">
                        <i class="fas fa-user"></i> User Dashboard
                    </a>
                    <a href="../logout.php" class="btn btn-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
            
            <!-- Admin Statistics -->
            <div class="dashboard-stats">
                <div class="stat-card">
                    <h3>Total Users</h3>
                    <div class="value"><?php echo number_format($total_users); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Donations</h3>
                    <div class="value">GHS <?php echo number_format($total_donations); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Unread Messages</h3>
                    <div class="value"><?php echo number_format($total_messages); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Blog Posts</h3>
                    <div class="value"><?php echo number_format($total_posts); ?></div>
                </div>
            </div>
            
            <!-- Admin Menu -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; margin-top: 2rem;">
                <div class="card">
                    <div class="card-body" style="text-align: center;">
                        <i class="fas fa-users" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                        <h3 style="margin-bottom: 1rem;">User Management</h3>
                        <p style="color: var(--text-light); margin-bottom: 1.5rem;">View and manage user accounts</p>
                        <a href="users.php" class="btn btn-primary">Manage Users</a>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-body" style="text-align: center;">
                        <i class="fas fa-newspaper" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                        <h3 style="margin-bottom: 1rem;">Blog Posts</h3>
                        <p style="color: var(--text-light); margin-bottom: 1.5rem;">Create and manage blog content</p>
                        <a href="blog.php" class="btn btn-primary">Manage Posts</a>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-body" style="text-align: center;">
                        <i class="fas fa-bullhorn" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                        <h3 style="margin-bottom: 1rem;">Campaigns</h3>
                        <p style="color: var(--text-light); margin-bottom: 1.5rem;">Manage environmental campaigns</p>
                        <a href="campaigns.php" class="btn btn-primary">Manage Campaigns</a>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-body" style="text-align: center;">
                        <i class="fas fa-envelope" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                        <h3 style="margin-bottom: 1rem;">Messages</h3>
                        <p style="color: var(--text-light); margin-bottom: 1.5rem;">View contact form messages</p>
                        <a href="messages.php" class="btn btn-primary">View Messages</a>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-body" style="text-align: center;">
                        <i class="fas fa-donate" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                        <h3 style="margin-bottom: 1rem;">Donations</h3>
                        <p style="color: var(--text-light); margin-bottom: 1.5rem;">View donation records</p>
                        <a href="donations.php" class="btn btn-primary">View Donations</a>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-body" style="text-align: center;">
                        <i class="fas fa-cog" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                        <h3 style="margin-bottom: 1rem;">Site Settings</h3>
                        <p style="color: var(--text-light); margin-bottom: 1.5rem;">Configure website settings</p>
                        <a href="settings.php" class="btn btn-primary">Settings</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
