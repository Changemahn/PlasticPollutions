<?php
$page_title = 'Donations';
require_once '../includes/config.php';
require_once '../includes/functions.php';

require_admin();

$pdo = db();

// Get all donations with user information
$donations = $pdo->query("
    SELECT d.*, u.first_name, u.last_name, u.email 
    FROM donations d 
    JOIN users u ON d.user_id = u.id 
    ORDER BY d.donation_date DESC
")->fetchAll();

$total_amount = $pdo->query("SELECT COALESCE(SUM(amount), 0) as total FROM donations WHERE status = 'completed'")->fetch()['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donations - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <div class="dashboard-header">
                <div>
                    <h1 style="color: var(--primary-color);">Donation Records</h1>
                    <p style="color: var(--text-light);">View all donation transactions</p>
                </div>
                <a href="dashboard.php" class="btn btn-outline">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
            
            <div class="card" style="margin-bottom: 2rem; background: linear-gradient(135deg, var(--primary-dark), var(--primary-color)); color: white;">
                <div class="card-body" style="text-align: center;">
                    <h2 style="margin-bottom: 0.5rem;">Total Donations Received</h2>
                    <div style="font-size: 3rem; font-weight: bold;">GHS <?php echo number_format($total_amount); ?></div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <?php if (empty($donations)): ?>
                        <p style="text-align: center; padding: 2rem; color: var(--text-light);">No donations recorded yet.</p>
                    <?php else: ?>
                        <div style="overflow-x: auto;">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Donor</th>
                                        <th>Email</th>
                                        <th>Amount</th>
                                        <th>Method</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($donations as $donation): ?>
                                    <tr>
                                        <td><?php echo date('M d, Y H:i', strtotime($donation['donation_date'])); ?></td>
                                        <td><?php echo htmlspecialchars($donation['first_name'] . ' ' . $donation['last_name']); ?></td>
                                        <td><?php echo htmlspecialchars($donation['email']); ?></td>
                                        <td><strong>GHS <?php echo number_format($donation['amount']); ?></strong></td>
                                        <td><?php echo ucfirst(str_replace('_', ' ', $donation['payment_method'])); ?></td>
                                        <td>
                                            <span style="color: <?php echo $donation['status'] === 'completed' ? 'var(--success)' : 'var(--warning)'; ?>;">
                                                <?php echo ucfirst($donation['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
