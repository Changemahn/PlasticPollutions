<?php
$page_title = 'Messages';
require_once '../includes/config.php';
require_once '../includes/functions.php';

require_admin();

$pdo = db();

// Handle message actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'mark_read') {
    $message_id = intval($_POST['message_id'] ?? 0);
    try {
        $stmt = $pdo->prepare("UPDATE contact_messages SET is_read = 1 WHERE id = ?");
        $stmt->execute([$message_id]);
        set_flash_message('success', 'Message marked as read');
    } catch (Exception $e) {
        set_flash_message('error', 'Failed to update message');
    }
    header('Location: messages.php');
    exit;
}

// Get all messages
$messages = $pdo->query("SELECT * FROM contact_messages ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <div class="dashboard-header">
                <div>
                    <h1 style="color: var(--primary-color);">Contact Messages</h1>
                    <p style="color: var(--text-light);">View messages from the contact form</p>
                </div>
                <a href="dashboard.php" class="btn btn-outline">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
            
            <?php if (has_flash_message('success')): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars(get_flash_message('success')); ?>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-body">
                    <?php if (empty($messages)): ?>
                        <p style="text-align: center; padding: 2rem; color: var(--text-light);">No messages yet.</p>
                    <?php else: ?>
                        <div style="overflow-x: auto;">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Status</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Subject</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($messages as $message): ?>
                                    <tr style="<?php echo $message['is_read'] ? '' : 'background: #E8F5E9;'; ?>">
                                        <td>
                                            <?php if ($message['is_read']): ?>
                                                <i class="fas fa-envelope-open" style="color: var(--text-light);"></i>
                                            <?php else: ?>
                                                <i class="fas fa-envelope" style="color: var(--primary-color);"></i>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($message['name']); ?></td>
                                        <td><?php echo htmlspecialchars($message['email']); ?></td>
                                        <td><?php echo htmlspecialchars($message['subject']); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($message['created_at'])); ?></td>
                                        <td>
                                            <?php if (!$message['is_read']): ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="action" value="mark_read">
                                                    <input type="hidden" name="message_id" value="<?php echo $message['id']; ?>">
                                                    <button type="submit" class="btn btn-outline" style="padding: 0.25rem 0.5rem; font-size: 0.875rem;" title="Mark as read">
                                                        <i class="fas fa-check"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr style="<?php echo $message['is_read'] ? '' : 'background: #E8F5E9;'; ?>">
                                        <td colspan="6" style="padding: 1rem;">
                                            <strong>Message:</strong><br>
                                            <?php echo nl2br(htmlspecialchars($message['message'])); ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>
