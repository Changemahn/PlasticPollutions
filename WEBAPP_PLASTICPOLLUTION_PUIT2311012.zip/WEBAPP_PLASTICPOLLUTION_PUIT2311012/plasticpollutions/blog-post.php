<?php
$page_title = 'Blog Post';
require_once 'includes/config.php';
require_once 'includes/functions.php';

$pdo = db();

// Get post ID from URL
$post_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($post_id === 0) {
    header('Location: latest.php');
    exit;
}

// Fetch the blog post
$stmt = $pdo->prepare("SELECT * FROM blog_posts WHERE id = ? AND is_published = 1");
$stmt->execute([$post_id]);
$post = $stmt->fetch();

if (!$post) {
    header('Location: latest.php');
    exit;
}

$page_title = htmlspecialchars($post['title']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo htmlspecialchars($post['excerpt'] ?? substr(strip_tags($post['content']), 0, 150)); ?>">
    <title><?php echo $page_title; ?> - PlasticPollutions</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <!-- Back to News -->
            <div style="margin-bottom: 2rem;">
                <a href="latest.php" class="btn btn-outline" style="display: inline-flex; align-items: center; gap: 0.5rem;">
                    <i class="fas fa-arrow-left"></i> Back to News
                </a>
            </div>
            
            <!-- Article Header -->
            <div style="text-align: center; margin-bottom: 2rem;">
                <span style="background: var(--primary-color); color: white; padding: 0.5rem 1rem; border-radius: 20px; font-size: 0.9rem;">
                    <?php echo htmlspecialchars($post['category'] ?? 'News'); ?>
                </span>
                <h1 style="margin: 1.5rem 0 1rem; color: var(--primary-color); font-size: 2.5rem;">
                    <?php echo htmlspecialchars($post['title']); ?>
                </h1>
                <p style="color: var(--text-light);">
                    <i class="far fa-calendar"></i> <?php echo date('F d, Y', strtotime($post['created_at'])); ?>
                </p>
            </div>
            
            <!-- Featured Image -->
            <?php if ($post['featured_image']): ?>
            <div style="margin-bottom: 2rem;">
                <img src="<?php echo htmlspecialchars($post['featured_image']); ?>" 
                     alt="<?php echo htmlspecialchars($post['title']); ?>" 
                     style="width: 100%; max-height: 500px; object-fit: cover; border-radius: 8px;">
            </div>
            <?php endif; ?>
            
            <!-- Article Content -->
            <article class="card" style="padding: 2rem;">
                <div class="card-body" style="line-height: 1.8; font-size: 1.1rem;">
                    <?php echo $post['content']; ?>
                </div>
            </article>
            
            <!-- Video Section -->
            <?php if (!empty($post['video_url'])): ?>
            <div style="margin-top: 2rem;">
                <h2 style="margin-bottom: 1rem; color: var(--primary-color);">Related Video</h2>
                <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; border-radius: 8px;">
                    <?php
                    // Check if it's a YouTube URL
                    if (strpos($post['video_url'], 'youtube.com') !== false || strpos($post['video_url'], 'youtu.be') !== false) {
                        // Extract YouTube video ID
                        $video_id = '';
                        if (strpos($post['video_url'], 'youtube.com') !== false) {
                            parse_str(parse_url($post['video_url'], PHP_URL_QUERY), $params);
                            $video_id = $params['v'] ?? '';
                        } else {
                            $video_id = substr(parse_url($post['video_url'], PHP_URL_PATH), 1);
                        }
                        ?>
                        <iframe src="https://www.youtube.com/embed/HGxBRTV3ejo"/<?php echo $video_id; ?>" 
                                style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: 0;"
                                allowfullscreen
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture">
                        </iframe>
                    <?php } else { ?>
                        <video controls style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;">
                            <source src="<?php echo htmlspecialchars($post['video_url']); ?>" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                    <?php } ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Additional Images Gallery for Marine Life Impact -->
            <?php if ($post['slug'] === 'impact-of-plastic-on-marine-life'): ?>
            <div style="margin-top: 3rem;">
                <h2 style="margin-bottom: 1.5rem; color: var(--primary-color); text-align: center;">Gallery: Impact of Plastic on Marine Life</h2>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem;">
                    <div class="card">
                        <img src="images/ocean.jpg" alt="Ocean conservation" style="width: 100%; height: 250px; object-fit: cover;">
                        <div class="card-body" style="padding: 1rem;">
                            <h4 style="margin-bottom: 0.5rem;">Ocean Pollution</h4>
                            <p style="color: var(--text-light); font-size: 0.9rem;">Plastic waste entering our oceans threatens marine ecosystems worldwide.</p>
                        </div>
                    </div>
                    <div class="card">
                        <img src="images/life.jpg" alt="Wildlife protection" style="width: 100%; height: 250px; object-fit: cover;">
                        <div class="card-body" style="padding: 1rem;">
                            <h4 style="margin-bottom: 0.5rem;">Marine Wildlife</h4>
                            <p style="color: var(--text-light); font-size: 0.9rem;">Sea turtles, whales, and other marine life suffer from plastic ingestion.</p>
                        </div>
                    </div>
                    <div class="card">
                        <img src="images/ocean-pollu.jpg" alt="Plastic pollution impact" style="width: 100%; height: 250px; object-fit: cover;">
                        <div class="card-body" style="padding: 1rem;">
                            <h4 style="margin-bottom: 0.5rem;">Ecosystem Damage</h4>
                            <p style="color: var(--text-light); font-size: 0.9rem;">Coral reefs and marine habitats are being destroyed by plastic debris.</p>
                        </div>
                    </div>
                    <div class="card">
                        <img src="images/recycle.jpg" alt="Recycling solutions" style="width: 100%; height: 250px; object-fit: cover;">
                        <div class="card-body" style="padding: 1rem;">
                            <h4 style="margin-bottom: 0.5rem;">Recycling Solutions</h4>
                            <p style="color: var(--text-light); font-size: 0.9rem;">Proper recycling can help reduce plastic waste in our oceans.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Video Gallery -->
            <div style="margin-top: 3rem;">
                <h2 style="margin-bottom: 1.5rem; color: var(--primary-color); text-align: center;">Videos: Marine Life Impact</h2>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 1.5rem;">
                    <div class="card">
                        <div style="position: relative; padding-bottom: 56.25%; height: 0;">
                            <iframe src="https://www.youtube.com/embed/HGxBRTV3ejo" 
                                    style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: 0; border-radius: 8px 8px 0 0;"
                                    allowfullscreen
                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture">
                            </iframe>
                        </div>
                        <div class="card-body" style="padding: 1rem;">
                            <h4 style="margin-bottom: 0.5rem;">Plastic Pollution in Our Oceans</h4>
                            <p style="color: var(--text-light); font-size: 0.9rem;">Learn about the devastating impact of plastic on marine ecosystems.</p>
                        </div>
                    </div>
                    <div class="card">
                        <div style="position: relative; padding-bottom: 56.25%; height: 0;">
                            <iframe src="https://www.youtube.com/embed/dnNsHTy1WIo" 
                                    style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: 0; border-radius: 8px 8px 0 0;"
                                    allowfullscreen
                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture">
                            </iframe>
                        </div>
                        <div class="card-body" style="padding: 1rem;">
                            <h4 style="margin-bottom: 0.5rem;">Saving Marine Life from Plastic</h4>
                            <p style="color: var(--text-light); font-size: 0.9rem;">See how plastic affects sea turtles and other marine animals.</p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Share Section -->
            <div style="margin-top: 3rem; text-align: center;">
                <h3 style="margin-bottom: 1rem;">Share This Article</h3>
                <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']); ?>" 
                       target="_blank" 
                       class="btn btn-outline" 
                       style="color: #1877f2; border-color: #1877f2;">
                        <i class="fab fa-facebook"></i> Share
                    </a>
                    <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']); ?>&text=<?php echo urlencode($post['title']); ?>" 
                       target="_blank" 
                       class="btn btn-outline" 
                       style="color: #1da1f2; border-color: #1da1f2;">
                        <i class="fab fa-twitter"></i> Tweet
                    </a>
                    <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']); ?>&title=<?php echo urlencode($post['title']); ?>" 
                       target="_blank" 
                       class="btn btn-outline" 
                       style="color: #0077b5; border-color: #0077b5;">
                        <i class="fab fa-linkedin"></i> Share
                    </a>
                </div>
            </div>
            
            <!-- Call to Action -->
            <div style="margin-top: 3rem; text-align: center;">
                <div class="card" style="background: var(--primary-dark); color: white;">
                    <div class="card-body" style="padding: 2rem;">
                        <h3 style="margin-bottom: 1rem;">Take Action Now</h3>
                        <p style="margin-bottom: 1.5rem; opacity: 0.9;">Join us in the fight against plastic pollution. Every action counts!</p>
                        <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                            <a href="sign-petition.php" class="btn" style="background: white; color: var(--primary-dark);">Sign Petition</a>
                            <a href="donate.php" class="btn" style="background: white; color: var(--primary-dark);">Donate</a>
                            <a href="help.php" class="btn" style="background: white; color: var(--primary-dark);">Volunteer</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>
