// Latest page JavaScript
// Handles video playback and post viewing

document.addEventListener('DOMContentLoaded', function() {
    // Initialize page
    initializeLatestPage();
});

function initializeLatestPage() {
    // Add event listeners for video buttons
    const playButtons = document.querySelectorAll('[onclick*="playVideo"]');
    playButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const postId = this.getAttribute('onclick').match(/playVideo\((\d+)\)/)[1];
            playVideo(postId);
        });
    });
}

function playVideo(postId) {
    // Create modal for video playback
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.9);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
    `;
    
    modal.innerHTML = `
        <div style="position: relative; max-width: 800px; width: 90%;">
            <button onclick="this.parentElement.parentElement.remove()" style="position: absolute; top: -40px; right: 0; background: white; border: none; padding: 10px; border-radius: 50%; cursor: pointer;">
                <i class="fas fa-times"></i>
            </button>
            <video controls autoplay style="width: 100%; border-radius: 8px;">
                <source src="videos/cleanup-event.mp4" type="video/mp4">
                <source src="videos/student-campaign.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Close modal when clicking outside
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.remove();
        }
    });
}

function viewPost(postId) {
    // Show post details in a modal
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
        overflow-y: auto;
    `;
    
    modal.innerHTML = `
        <div style="background: white; padding: 2rem; border-radius: 8px; max-width: 600px; width: 90%; margin: 2rem; position: relative;">
            <button onclick="this.parentElement.parentElement.remove()" style="position: absolute; top: 10px; right: 10px; background: none; border: none; font-size: 1.5rem; cursor: pointer;">
                <i class="fas fa-times"></i>
            </button>
            <h2 style="margin-bottom: 1rem;">Loading...</h2>
            <div id="postContent">
                <p style="color: var(--text-light);">Loading article content...</p>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Close modal when clicking outside
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.remove();
        }
    });
    
    // Load post content (simulated)
    setTimeout(() => {
        const postContent = document.getElementById('postContent');
        if (postContent) {
            postContent.innerHTML = `
                <p style="color: var(--text-light); line-height: 1.8;">
                    This is a sample blog post about plastic pollution and environmental conservation efforts. 
                    The full article would contain detailed information about our activities, research findings, 
                    and ways to get involved in our environmental initiatives.
                </p>
                <div style="margin-top: 2rem; padding-top: 1rem; border-top: 1px solid #ddd;">
                    <p style="color: var(--text-light); font-size: 0.875rem;">
                        <strong>Published:</strong> ${new Date().toLocaleDateString()}<br>
                        <strong>Category:</strong> Environment<br>
                        <strong>Author:</strong> PlasticPollutions Team
                    </p>
                </div>
            `;
        }
    }, 500);
}
