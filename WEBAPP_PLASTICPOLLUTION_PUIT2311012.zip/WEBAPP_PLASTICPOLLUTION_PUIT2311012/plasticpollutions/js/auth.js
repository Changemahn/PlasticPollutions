// Authentication form JavaScript
// Handles form validation and user feedback

document.addEventListener('DOMContentLoaded', function() {
    // Password strength indicator
    const passwordFields = document.querySelectorAll('input[type="password"]');
    
    passwordFields.forEach(field => {
        field.addEventListener('input', function() {
            const password = this.value;
            const strength = checkPasswordStrength(password);
            
            // Update any strength indicator if present
            const strengthIndicator = this.parentElement.querySelector('.password-strength');
            if (strengthIndicator) {
                strengthIndicator.textContent = strength.message;
                strengthIndicator.style.color = strength.color;
            }
        });
    });
    
    // Password confirmation matching
    const confirmPasswordFields = document.querySelectorAll('input[name="confirm_password"]');
    
    confirmPasswordFields.forEach(field => {
        field.addEventListener('input', function() {
            const password = this.form.querySelector('input[name="password"]').value;
            const confirm = this.value;
            
            if (confirm && password !== confirm) {
                this.style.borderColor = 'var(--danger)';
            } else {
                this.style.borderColor = '#ddd';
            }
        });
    });
    
    // Form submission validation
    const authForms = document.querySelectorAll('.auth-form');
    
    authForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            let isValid = true;
            const errors = [];
            
            // Check required fields
            const requiredFields = form.querySelectorAll('[required]');
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    errors.push(`${field.previousElementSibling.textContent} is required`);
                    field.style.borderColor = 'var(--danger)';
                }
            });
            
            // Email validation
            const emailField = form.querySelector('input[type="email"]');
            if (emailField && emailField.value) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(emailField.value)) {
                    isValid = false;
                    errors.push('Please enter a valid email address');
                    emailField.style.borderColor = 'var(--danger)';
                }
            }
            
            // Password validation
            const passwordField = form.querySelector('input[name="password"]');
            if (passwordField && passwordField.value) {
                const password = passwordField.value;
                if (password.length < 8) {
                    isValid = false;
                    errors.push('Password must be at least 8 characters long');
                }
                
                const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
                if (!passwordRegex.test(password)) {
                    isValid = false;
                    errors.push('Password must contain uppercase, lowercase, number, and special character');
                }
            }
            
            // Password confirmation
            const confirmPasswordField = form.querySelector('input[name="confirm_password"]');
            if (confirmPasswordField && passwordField) {
                if (passwordField.value !== confirmPasswordField.value) {
                    isValid = false;
                    errors.push('Passwords do not match');
                    confirmPasswordField.style.borderColor = 'var(--danger)';
                }
            }
            
            if (!isValid) {
                e.preventDefault();
                alert(errors.join('\n'));
            }
        });
    });
    
    // Clear validation styles on input
    document.querySelectorAll('input').forEach(field => {
        field.addEventListener('input', function() {
            this.style.borderColor = '#ddd';
        });
    });
});

function checkPasswordStrength(password) {
    let strength = 0;
    
    if (password.length >= 8) strength += 1;
    if (password.length >= 12) strength += 1;
    if (/[a-z]/.test(password)) strength += 1;
    if (/[A-Z]/.test(password)) strength += 1;
    if (/\d/.test(password)) strength += 1;
    if (/[@$!%*?&]/.test(password)) strength += 1;
    
    if (strength <= 2) {
        return { message: 'Weak', color: 'var(--danger)' };
    } else if (strength <= 4) {
        return { message: 'Medium', color: 'var(--warning)' };
    } else {
        return { message: 'Strong', color: 'var(--success)' };
    }
}
