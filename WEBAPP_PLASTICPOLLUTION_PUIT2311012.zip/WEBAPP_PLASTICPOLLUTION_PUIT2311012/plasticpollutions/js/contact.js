// Contact form JavaScript
// Handles form validation and submission

document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.querySelector('form[action="contact.php"]');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            let isValid = true;
            const errors = [];
            
            // Name validation
            const nameField = document.getElementById('name');
            if (nameField) {
                const name = nameField.value.trim();
                if (!name) {
                    isValid = false;
                    errors.push('Name is required');
                    nameField.style.borderColor = 'var(--danger)';
                } else if (!/^[a-zA-Z\s]{2,100}$/.test(name)) {
                    isValid = false;
                    errors.push('Name must be 2-100 letters only');
                    nameField.style.borderColor = 'var(--danger)';
                }
            }
            
            // Email validation
            const emailField = document.getElementById('email');
            if (emailField) {
                const email = emailField.value.trim();
                if (!email) {
                    isValid = false;
                    errors.push('Email is required');
                    emailField.style.borderColor = 'var(--danger)';
                } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                    isValid = false;
                    errors.push('Please enter a valid email address');
                    emailField.style.borderColor = 'var(--danger)';
                }
            }
            
            // Subject validation
            const subjectField = document.getElementById('subject');
            if (subjectField) {
                const subject = subjectField.value.trim();
                if (!subject) {
                    isValid = false;
                    errors.push('Subject is required');
                    subjectField.style.borderColor = 'var(--danger)';
                } else if (subject.length < 5 || subject.length > 200) {
                    isValid = false;
                    errors.push('Subject must be 5-200 characters');
                    subjectField.style.borderColor = 'var(--danger)';
                }
            }
            
            // Message validation
            const messageField = document.getElementById('message');
            if (messageField) {
                const message = messageField.value.trim();
                if (!message) {
                    isValid = false;
                    errors.push('Message is required');
                    messageField.style.borderColor = 'var(--danger)';
                } else if (message.length < 10 || message.length > 5000) {
                    isValid = false;
                    errors.push('Message must be 10-5000 characters');
                    messageField.style.borderColor = 'var(--danger)';
                }
            }
            
            if (!isValid) {
                e.preventDefault();
                alert(errors.join('\n'));
            }
        });
    }
    
    // Clear validation styles on input
    document.querySelectorAll('#name, #email, #subject, #message').forEach(field => {
        if (field) {
            field.addEventListener('input', function() {
                this.style.borderColor = '#ddd';
            });
        }
    });
});
