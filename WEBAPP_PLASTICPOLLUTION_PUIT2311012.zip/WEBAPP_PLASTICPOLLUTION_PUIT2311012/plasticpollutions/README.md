# PlasticPollutions Web Application

A comprehensive web application for Pentecost University's environmental action group dedicated to reducing plastic pollution and promoting sustainability.

## Features

### User Features
- **Secure Registration & Login System**
  - Password encryption using bcrypt
  - Login attempt tracking with automatic lockout after 3 failed attempts
  - Session management
  - Unique visitor ID generation (PU + 6 digits)

- **User Dashboard**
  - Profile management (CRUD operations)
  - Password change functionality
  - Donation history tracking
  - Pledge management
  - Activity monitoring

- **Donation System**
  - Secure donation processing
  - Multiple payment methods (Card, Mobile Money, Bank Transfer)
  - Donation history and statistics
  - Total contribution tracking

- **Interactive Pages**
  - Home page with image slider, animated counters, and sign-up modal
  - "What to Do About Plastic" with multimedia content and petition signing
  - Latest news blog-style page with pagination
  - Strategy page with goals and implementation timeline
  - Campaigns page with impact metrics
  - "How You Can Help" page with pledge system and impact calculator
  - Contact form with validation
  - Developer profiles page

### Admin Features
- **Admin Dashboard**
  - User management (view, activate/deactivate, delete)
  - Blog post management (create, edit, delete, publish)
  - Campaign management
  - Contact message management
  - Donation records viewing
  - Site settings configuration

### Technical Features
- **Security**
  - SQL injection prevention using PDO prepared statements
  - XSS protection through input sanitization
  - CSRF protection considerations
  - Secure password hashing
  - Session timeout management

- **Accessibility**
  - Responsive design for mobile and desktop
  - Skip to content links
  - ARIA labels for interactive elements
  - Keyboard navigation support
  - Semantic HTML structure

- **User Experience**
  - Cookie notification system
  - Visitor counter
  - Social media integration
  - Twitter feed simulation
  - Dynamic content updates
  - Real-time statistics

## Technology Stack

- **Backend**: PHP 7.4+
- **Database**: MySQL/MariaDB
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Libraries**: Font Awesome (icons)
- **Server**: Apache (XAMPP recommended)

## Installation Instructions

### Prerequisites
- XAMPP (or WAMP/MAMP) with PHP and MySQL
- Web browser (Chrome, Firefox, Safari, or Edge)
- Text editor (VS Code, Sublime Text, etc.)

### Step 1: Setup Project Files
1. Copy the `plasticpollutions` folder to your XAMPP htdocs directory:
   ```
   C:\xampp\htdocs\plasticpollutions\
   ```

### Step 2: Create Database
1. Open phpMyAdmin (http://localhost/phpmyadmin)
2. Create a new database named `plasticpollutions`
3. Import the `database.sql` file:
   - Click on the `plasticpollutions` database
   - Click "Import" tab
   - Choose the `database.sql` file
   - Click "Go"

### Step 3: Configure Database Connection
The database configuration is in `includes/config.php`. Default settings:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'plasticpollutions');
```

If your MySQL password is different, update `DB_PASS` accordingly.

### Step 4: Start Apache and MySQL
1. Open XAMPP Control Panel
2. Start Apache
3. Start MySQL

### Step 5: Access the Application
Open your web browser and navigate to:
```
http://localhost/plasticpollutions/
```

## Default Admin Account

- **Email**: admin@plasticpollutions.org
- **Password**: Admin@123

**Important**: Change the admin password immediately after first login for security.

## File Structure

```
plasticpollutions/
├── admin/                  # Admin panel
│   ├── dashboard.php
│   ├── users.php
│   ├── blog.php
│   ├── campaigns.php
│   ├── messages.php
│   └── donations.php
├── css/                    # Stylesheets
│   └── style.css
├── js/                     # JavaScript files
│   ├── main.js
│   ├── home.js
│   ├── auth.js
│   └── contact.js
├── includes/               # PHP includes
│   ├── config.php
│   ├── db.php
│   ├── functions.php
│   ├── header.php
│   └── footer.php
├── images/                 # Image assets
├── uploads/                # User uploaded files
├── assets/                 # Additional assets
├── index.php              # Home page
├── register.php           # Registration
├── login.php              # Login
├── logout.php             # Logout
├── dashboard.php          # User dashboard
├── donate.php             # Donation page
├── contact.php            # Contact form
├── what-to-do.php         # Plastic information
├── latest.php             # Blog/news
├── strategy.php           # Strategy page
├── campaigns.php          # Campaigns page
├── help.php               # How to help
├── developers.php         # Developer profiles
├── sign-petition.php      # Petition signing
├── forgot-password.php    # Password reset
├── database.sql           # Database schema
├── PROJECT_REFLECTION_REPORT.md
└── README.md
```

## Security Considerations

1. **Change Default Passwords**: Immediately change the default admin password
2. **File Permissions**: Ensure proper permissions on sensitive files
3. **HTTPS**: Use HTTPS in production for secure data transmission
4. **Regular Updates**: Keep PHP, MySQL, and dependencies updated
5. **Backup**: Regularly backup the database and important files

## Browser Compatibility

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Mobile Responsiveness

The application is fully responsive and works on:
- Desktop computers (1920x1080 and above)
- Laptops (1366x768 and above)
- Tablets (768px and above)
- Mobile phones (320px and above)

## SEO Features

- Meta tags for search engines
- Open Graph tags for social media
- Semantic HTML structure
- Optimized page loading
- Clean URL structure

## Accessibility Features

- WCAG 2.1 AA compliant
- Keyboard navigation support
- Screen reader friendly
- High contrast options
- Alt text for images

## Performance Optimization

- CSS and JavaScript minification (recommended for production)
- Image optimization
- Database indexing
- Efficient queries using PDO

## Troubleshooting

### Database Connection Error
- Ensure MySQL is running in XAMPP
- Check database credentials in `includes/config.php`
- Verify database name matches in config

### Images Not Displaying
- Check image file permissions
- Verify image paths in code
- Ensure images are in the correct folder

### Session Issues
- Check PHP session configuration
- Ensure cookies are enabled in browser
- Clear browser cache

## Support

For issues or questions:
- Email: info@plasticpollutions.org
- Pentecost University

## License

This project is developed for educational purposes at Pentecost University.

## Credits

Developed by the PlasticPollutions team at Pentecost University:
- Kwame Mensah - Lead Developer & Database Specialist
- Ama Ofori - Frontend Developer & UI/UX Designer
- Kojo Asante - Backend Developer & Security Specialist
- Efua Boateng - Full Stack Developer & Content Manager

## Version

Version 1.0.0 - Initial Release (May 2026)
