<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

$errors = [];
$success = false;

if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize_input($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    // Validation
    if (empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    
    if (empty($password)) {
        $errors[] = "Password is required";
    }
    
    if (empty($errors)) {
        // Check if account is locked
        if (is_account_locked($email)) {
            $remaining = get_remaining_lockout_time($email);
            $errors[] = "Account locked. Please try again in $remaining minute(s).";
        } else {
            try {
                $pdo = db();
                $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
                $stmt->execute([$email]);
                $user = $stmt->fetch();
                
                if ($user && verify_password($password, $user['password'])) {
                    if (!$user['is_active']) {
                        $errors[] = "Account is deactivated. Please contact support.";
                    } else {
                        // Successful login
                        record_login_attempt($email, true);
                        
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['visitor_id'] = $user['visitor_id'];
                        $_SESSION['email'] = $user['email'];
                        $_SESSION['first_name'] = $user['first_name'];
                        $_SESSION['last_name'] = $user['last_name'];
                        $_SESSION['role'] = $user['role'];
                        $_SESSION['last_activity'] = time();
                        
                        set_flash_message('success', 'Welcome back, ' . htmlspecialchars($user['first_name']) . '!');
                        
                        if ($user['role'] === 'admin') {
                            header('Location: admin/dashboard.php');
                        } else {
                            header('Location: dashboard.php');
                        }
                        exit;
                    }
                } else {
                    // Failed login
                    record_login_attempt($email, false);
                    $errors[] = "Invalid email or password";
                }
            } catch (Exception $e) {
                $errors[] = "Login failed: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Login to PlasticPollutions - Pentecost University's environmental action group">
    <meta name="keywords" content="plastic pollution, environment, recycling, sustainability, Pentecost University">
    <title>Login - PlasticPollutions</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main class="container">
        <div class="auth-container">
            <div class="auth-box">
                <h1>Welcome Back</h1>
                <p class="auth-subtitle">Login to your account</p>
                
                <?php if (has_flash_message('success')): ?>
                    <div class="alert alert-success">
                        <?php echo htmlspecialchars(get_flash_message('success')); ?>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <?php foreach ($errors as $error): ?>
                            <p><?php echo htmlspecialchars($error); ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="login.php" class="auth-form">
                    <div class="form-group">
                        <label for="email">Email Address *</label>
                        <input type="email" id="email" name="email" 
                               value="<?php echo htmlspecialchars($email ?? ''); ?>" 
                               required aria-required="true">
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password *</label>
                        <input type="password" id="password" name="password" 
                               required aria-required="true">
                    </div>
                    
                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="remember"> Remember me
                        </label>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-block">Login</button>
                </form>
                
                <p class="auth-footer">
                    Don't have an account? <a href="register.php">Register here</a>
                </p>
                <p class="auth-footer">
                    <a href="forgot-password.php">Forgot password?</a>
                </p>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    <script src="js/auth.js"></script>
</body>
</html>
