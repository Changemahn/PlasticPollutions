<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'plasticpollutions');

// Site Configuration
define('SITE_NAME', 'PlasticPollutions');
define('SITE_URL', 'http://localhost/plasticpollutions');
define('SITE_EMAIL', 'info@plasticpollutions.org');

// Security Configuration
define('MAX_LOGIN_ATTEMPTS', 3);
define('LOCKOUT_TIME', 180); // 3 minutes in seconds
define('SESSION_TIMEOUT', 3600); // 1 hour

// File Upload Configuration
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 5242880); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'pdf']);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Error Reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone
date_default_timezone_set('Africa/Accra');
?>
