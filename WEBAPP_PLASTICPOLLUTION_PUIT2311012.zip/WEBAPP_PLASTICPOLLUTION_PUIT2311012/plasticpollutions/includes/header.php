<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

// Track visitor
track_visitor();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="PlasticPollutions - Pentecost University's environmental action group fighting plastic pollution and promoting sustainability">
    <meta name="keywords" content="plastic pollution, environment, recycling, sustainability, Pentecost University, Ghana">
    <meta name="author" content="PlasticPollutions Team">
    <meta name="robots" content="index, follow">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' - ' : ''; ?>PlasticPollutions</title>
    
    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="PlasticPollutions - Environmental Action Group">
    <meta property="og:description" content="Join us in the fight against plastic pollution. Together we can make a difference.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo SITE_URL; ?>">
    <meta property="og:image" content="<?php echo SITE_URL; ?>/images/og-image.jpg">
    
    <!-- Twitter Card Meta Tags -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="PlasticPollutions - Environmental Action Group">
    <meta name="twitter:description" content="Join us in the fight against plastic pollution.">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    
    <!-- CSS -->
    <link rel="stylesheet" href="css/style.css">
    
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <a href="#main-content" class="skip-link">Skip to main content</a>
    
    <header>
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <i class="fas fa-leaf"></i>
                    PlasticPollutions
                </a>
                
                <div class="menu-toggle" id="menuToggle" aria-label="Toggle navigation menu" role="button" tabindex="0">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                
                <ul class="nav-menu" id="navMenu">
                    <li class="nav-item">
                        <a href="index.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <span class="nav-link dropdown-toggle">About</span>
                        <ul class="dropdown-menu">
                            <li><a href="what-to-do.php" class="dropdown-item">What to Do About Plastic</a></li>
                            <li><a href="strategy.php" class="dropdown-item">Our Strategy</a></li>
                            <li><a href="campaigns.php" class="dropdown-item">Campaigns</a></li>
                            <li><a href="developers.php" class="dropdown-item">Developers</a></li>
                            <li><a href="technology.php" class="dropdown-item">Technology Glossary</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="latest.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'latest.php' ? 'active' : ''; ?>">Latest News</a>
                    </li>
                    <li class="nav-item">
                        <a href="help.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'help.php' ? 'active' : ''; ?>">How You Can Help</a>
                    </li>
                    <li class="nav-item">
                        <a href="contact.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'contact.php' ? 'active' : ''; ?>">Contact Us</a>
                    </li>
                    <?php if (is_logged_in()): ?>
                        <li class="nav-item">
                            <a href="dashboard.php" class="nav-link">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a href="logout.php" class="nav-link">Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a href="login.php" class="nav-link">Login</a>
                        </li>
                        <li class="nav-item">
                            <a href="register.php" class="btn btn-primary">Sign Up</a>
                        </li>
                    <?php endif; ?>
                </ul>
                
                <div class="visitor-counter">
                    <i class="fas fa-users"></i>
                    <span><?php echo number_format(get_visitor_count()); ?></span> Visitors
                </div>
            </nav>
        </div>
    </header>
    
    <main id="main-content">
