<?php
require_once __DIR__ . '/db.php';

// Security Functions
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

function generate_visitor_id() {
    $pdo = db();
    $max_attempts = 100;
    $attempts = 0;
    
    while ($attempts < $max_attempts) {
        $visitor_id = 'PU' . str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
        
        // Validate format with regex
        if (!preg_match('/^PU\d{6}$/', $visitor_id)) {
            continue;
        }
        
        // Check uniqueness
        $stmt = $pdo->prepare("SELECT id FROM users WHERE visitor_id = ?");
        $stmt->execute([$visitor_id]);
        
        if ($stmt->rowCount() === 0) {
            return $visitor_id;
        }
        
        $attempts++;
    }
    
    throw new Exception("Could not generate unique visitor ID");
}

function hash_password($password) {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
}

function verify_password($password, $hash) {
    return password_verify($password, $hash);
}

function is_logged_in() {
    return isset($_SESSION['user_id']) && isset($_SESSION['visitor_id']);
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

function require_admin() {
    require_login();
    if ($_SESSION['role'] !== 'admin') {
        header('Location: dashboard.php');
        exit;
    }
}

if (!function_exists('get_current_user')) {
    function get_current_user() {
        try {
            $pdo = db();
            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            return $stmt->fetch();
        } catch (Exception $e) {
            return null;
        }
    }
}


function record_login_attempt($email, $success = false) {
    $pdo = db();
    
    if ($success) {
        // Clear failed attempts on successful login
        $stmt = $pdo->prepare("DELETE FROM login_attempts WHERE email = ?");
        $stmt->execute([$email]);
    } else {
        // Record failed attempt
        $stmt = $pdo->prepare("SELECT * FROM login_attempts WHERE email = ?");
        $stmt->execute([$email]);
        $attempt = $stmt->fetch();
        
        if ($attempt) {
            // Check if still locked out
            if ($attempt['lockout_until'] && strtotime($attempt['lockout_until']) > time()) {
                return false; // Still locked out
            }
            
            // Increment attempt count
            $new_count = $attempt['attempt_count'] + 1;
            $lockout_until = null;
            
            if ($new_count >= MAX_LOGIN_ATTEMPTS) {
                $lockout_until = date('Y-m-d H:i:s', time() + LOCKOUT_TIME);
            }
            
            $stmt = $pdo->prepare("UPDATE login_attempts SET attempt_count = ?, lockout_until = ?, last_attempt_at = NOW() WHERE email = ?");
            $stmt->execute([$new_count, $lockout_until, $email]);
        } else {
            // First failed attempt
            $stmt = $pdo->prepare("INSERT INTO login_attempts (email, attempt_count) VALUES (?, 1)");
            $stmt->execute([$email]);
        }
    }
    
    return true;
}

function is_account_locked($email) {
    $pdo = db();
    $stmt = $pdo->prepare("SELECT * FROM login_attempts WHERE email = ?");
    $stmt->execute([$email]);
    $attempt = $stmt->fetch();
    
    if ($attempt && $attempt['lockout_until']) {
        if (strtotime($attempt['lockout_until']) > time()) {
            return true;
        } else {
            // Lockout expired, clear it
            $stmt = $pdo->prepare("DELETE FROM login_attempts WHERE email = ?");
            $stmt->execute([$email]);
        }
    }
    
    return false;
}

function get_remaining_lockout_time($email) {
    $pdo = db();
    $stmt = $pdo->prepare("SELECT lockout_until FROM login_attempts WHERE email = ?");
    $stmt->execute([$email]);
    $attempt = $stmt->fetch();
    
    if ($attempt && $attempt['lockout_until']) {
        $lockout_time = strtotime($attempt['lockout_until']);
        $remaining = $lockout_time - time();
        return $remaining > 0 ? ceil($remaining / 60) : 0; // Return minutes
    }
    
    return 0;
}

// Visitor Tracking
function track_visitor() {
    $pdo = db();
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $visit_date = date('Y-m-d');
    
    $stmt = $pdo->prepare("SELECT * FROM visitors WHERE ip_address = ? AND visit_date = ?");
    $stmt->execute([$ip_address, $visit_date]);
    $visitor = $stmt->fetch();
    
    if ($visitor) {
        $stmt = $pdo->prepare("UPDATE visitors SET page_views = page_views + 1, last_visit = NOW() WHERE id = ?");
        $stmt->execute([$visitor['id']]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO visitors (ip_address, visit_date, page_views) VALUES (?, ?, 1)");
        $stmt->execute([$ip_address, $visit_date]);
    }
}

function get_visitor_count() {
    $pdo = db();
    $stmt = $pdo->query("SELECT COUNT(DISTINCT ip_address) as total FROM visitors");
    $result = $stmt->fetch();
    return $result['total'] ?? 0;
}

function get_total_page_views() {
    $pdo = db();
    $stmt = $pdo->query("SELECT SUM(page_views) as total FROM visitors");
    $result = $stmt->fetch();
    return $result['total'] ?? 0;
}

// Donation Functions
function get_user_donations($user_id) {
    $pdo = db();
    $stmt = $pdo->prepare("SELECT * FROM donations WHERE user_id = ? ORDER BY donation_date DESC");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}

function get_user_total_donations($user_id) {
    $pdo = db();
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) as total FROM donations WHERE user_id = ? AND status = 'completed'");
    $stmt->execute([$user_id]);
    $result = $stmt->fetch();
    return $result['total'] ?? 0;
}

function get_total_donations() {
    $pdo = db();
    $stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) as total FROM donations WHERE status = 'completed'");
    $result = $stmt->fetch();
    return $result['total'] ?? 0;
}

// File Upload Functions
function upload_file($file, $subdir = '') {
    if (!isset($file['error']) || is_array($file['error'])) {
        throw new Exception("Invalid file upload");
    }
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception("File upload error code: " . $file['error']);
    }
    
    if ($file['size'] > MAX_FILE_SIZE) {
        throw new Exception("File size exceeds maximum allowed");
    }
    
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($file_ext, ALLOWED_EXTENSIONS)) {
        throw new Exception("File type not allowed");
    }
    
    $upload_dir = UPLOAD_DIR . $subdir;
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    $filename = uniqid() . '.' . $file_ext;
    $filepath = $upload_dir . $filename;
    
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        throw new Exception("Failed to move uploaded file");
    }
    
    return $subdir . $filename;
}

// Cookie Functions
function set_cookie_consent($consent) {
    setcookie('cookie_consent', $consent, time() + (86400 * 365), '/'); // 1 year
}

function has_cookie_conent() {
    return isset($_COOKIE['cookie_consent']);
}

// Flash Messages
function set_flash_message($type, $message) {
    $_SESSION['flash'][$type] = $message;
}

function get_flash_message($type) {
    if (isset($_SESSION['flash'][$type])) {
        $message = $_SESSION['flash'][$type];
        unset($_SESSION['flash'][$type]);
        return $message;
    }
    return null;
}

function has_flash_message($type) {
    return isset($_SESSION['flash'][$type]);
}

// Pagination
function paginate($query, $page = 1, $per_page = 10, $params = []) {
    $pdo = db();
    $offset = ($page - 1) * $per_page;
    
    $count_query = "SELECT COUNT(*) as total FROM ($query) as count_table";
    $stmt = $pdo->prepare($count_query);
    $stmt->execute($params);
    $total = $stmt->fetch()['total'];
    
    $data_query = $query . " LIMIT $per_page OFFSET $offset";
    $stmt = $pdo->prepare($data_query);
    $stmt->execute($params);
    $data = $stmt->fetchAll();
    
    return [
        'data' => $data,
        'total' => $total,
        'page' => $page,
        'per_page' => $per_page,
        'total_pages' => ceil($total / $per_page)
    ];
}
?>
