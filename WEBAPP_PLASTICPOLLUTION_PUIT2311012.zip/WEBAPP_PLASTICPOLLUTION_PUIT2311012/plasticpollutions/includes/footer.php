    </main>
    
    <!-- Cookie Notification -->
    <?php if (!has_cookie_conent()): ?>
    <div class="cookie-notification" id="cookieNotification">
        <div class="cookie-content">
            <p>We use cookies to improve your experience. By continuing to use this site, you accept our use of cookies.</p>
        </div>
        <div class="cookie-buttons">
            <button class="btn btn-primary" id="acceptCookies">Accept</button>
            <button class="btn btn-outline" id="learnMoreCookies">Learn More</button>
        </div>
    </div>
    <?php endif; ?>
    
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>About Us</h3>
                    <p>PlasticPollutions is an environmental action group at Pentecost University dedicated to reducing plastic waste and protecting our oceans, wildlife, and environment.</p>
                    <div class="social-buttons" style="margin-top: 1rem;">
                        <a href="https://facebook.com" class="social-btn social-facebook" aria-label="Facebook" target="_blank" rel="noopener noreferrer">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="https://twitter.com" class="social-btn social-twitter" aria-label="Twitter" target="_blank" rel="noopener noreferrer">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="https://instagram.com" class="social-btn social-instagram" aria-label="Instagram" target="_blank" rel="noopener noreferrer">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="https://linkedin.com" class="social-btn social-linkedin" aria-label="LinkedIn" target="_blank" rel="noopener noreferrer">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        <a href="https://youtube.com" class="social-btn social-youtube" aria-label="YouTube" target="_blank" rel="noopener noreferrer">
                            <i class="fab fa-youtube"></i>
                        </a>
                    </div>
                </div>
                
                <div class="footer-section">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="what-to-do.php">What to Do About Plastic</a></li>
                        <li><a href="latest.php">Latest News</a></li>
                        <li><a href="campaigns.php">Our Campaigns</a></li>
                        <li><a href="help.php">How You Can Help</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h3>Get Involved</h3>
                    <ul>
                        <li><a href="register.php">Sign Up</a></li>
                        <li><a href="donate.php">Make a Donation</a></li>
                        <li><a href="help.php">Volunteer</a></li>
                        <li><a href="help.php">Sign a Petition</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h3>Contact Info</h3>
                    <ul>
                        <li><i class="fas fa-map-marker-alt"></i> Pentecost University, Accra, Ghana</li>
                        <li><i class="fas fa-envelope"></i> <?php echo SITE_EMAIL; ?></li>
                        <li><i class="fas fa-phone"></i> +233 530096029</li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> PlasticPollutions - Pentecost University. All rights reserved.</p>
                <p>Total Page Views: <?php echo number_format(get_total_page_views()); ?></p>
            </div>
        </div>
    </footer>
    
    <script src="js/main.js"></script>
</body>
</html>
