<?php
$page_title = 'Profile of Developers';
require_once 'includes/config.php';
require_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Meet the developers behind PlasticPollutions">
    <title>Profile of Developers - PlasticPollutions</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <h1 style="text-align: center; margin-bottom: 1rem; color: var(--primary-color);">Profile of Developers</h1>
            <p style="text-align: center; max-width: 800px; margin: 0 auto 3rem; color: var(--text-light);">
                Meet the team behind the PlasticPollutions web application. These dedicated individuals worked together to create this platform for environmental change.
            </p>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem;">
                <!-- Developer 1 -->
                <div class="card">
                    <div class="card-body" style="text-align: center;">
                        <img src="images/developers/moses_linjel.jpg" 
                             alt="Perez Elijah Korbla" 
                             style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; margin: 0 auto 1.5rem; border: 4px solid var(--primary-light);">
                        <h3 style="margin-bottom: 0.5rem;">Perez Elijah Korbla</h3>
                        <p style="color: var(--primary-color); font-weight: 500; margin-bottom: 1rem;">Lead Developer & Database Specialist</p>
                        <p style="color: var(--text-light); margin-bottom: 1.5rem; line-height: 1.6;">
                            "Technology is a powerful tool for environmental advocacy. I believe in building systems that make it easy for people to take action and make a difference."
                        </p>
                        <div class="social-buttons" style="justify-content: center;">
                            <a href="#" class="social-btn social-linkedin" aria-label="LinkedIn">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                            <a href="#" class="social-btn social-github" aria-label="GitHub" style="background: #333;">
                                <i class="fab fa-github"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Developer 2 -->
                <div class="card">
                    <div class="card-body" style="text-align: center;">
                        <img src="images/developers/adjei_jonah.jpg" 
                             alt="Amoako Ajei Jonathan" 
                             style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; margin: 0 auto 1.5rem; border: 4px solid var(--primary-light);">
                        <h3 style="margin-bottom: 0.5rem;"> Amoako Adjei Jonathan </h3>
                        <p style="color: var(--primary-color); font-weight: 500; margin-bottom: 1rem;">Frontend Developer & UI/UX Designer</p>
                        <p style="color: var(--text-light); margin-bottom: 1.5rem; line-height: 1.6;">
                            "Good design is not just about aesthetics—it's about creating intuitive experiences that inspire users to engage with important causes."
                        </p>
                        <div class="social-buttons" style="justify-content: center;">
                            <a href="#" class="social-btn social-linkedin" aria-label="LinkedIn">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                            <a href="#" class="social-btn social-github" aria-label="GitHub" style="background: #333;">
                                <i class="fab fa-github"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Developer 3 -->
                <div class="card">
                    <div class="card-body" style="text-align: center;">
                        <img src="images/developers/Prince_Kwofie.jpg" 
                             alt="Kwofie_Prince" 
                             style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; margin: 0 auto 1.5rem; border: 4px solid var(--primary-light);">
                        <h3 style="margin-bottom: 0.5rem;">Kwofie Prince</h3>
                        <p style="color: var(--primary-color); font-weight: 500; margin-bottom: 1rem;">Backend Developer & Security Specialist</p>
                        <p style="color: var(--text-light); margin-bottom: 1.5rem; line-height: 1.6;">
                            "Security and privacy are fundamental rights. I'm committed to building systems that protect user data while enabling meaningful participation in environmental initiatives."
                        </p>
                        <div class="social-buttons" style="justify-content: center;">
                            <a href="#" class="social-btn social-linkedin" aria-label="LinkedIn">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                            <a href="#" class="social-btn social-github" aria-label="GitHub" style="background: #333;">
                                <i class="fab fa-github"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Developer 4 -->
                <div class="card">
                    <div class="card-body" style="text-align: center;">
                        <img src="images/developers/eshun_ebo.jpg" 
                             alt="Ebenezer Adamu" 
                             style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; margin: 0 auto 1.5rem; border: 4px solid var(--primary-light);">
                        <h3 style="margin-bottom: 0.5rem;">Ebenezer Adamu</h3>
                        <p style="color: var(--primary-color); font-weight: 500; margin-bottom: 1rem;">Full Stack Developer & Content Manager</p>
                        <p style="color: var(--text-light); margin-bottom: 1.5rem; line-height: 1.6;">
                            "Every line of code we write has the potential to create positive change. I'm passionate about using technology to solve real-world environmental challenges."
                        </p>
                        <div class="social-buttons" style="justify-content: center;">
                            <a href="#" class="social-btn social-linkedin" aria-label="LinkedIn">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                            <a href="#" class="social-btn social-github" aria-label="GitHub" style="background: #333;">
                                <i class="fab fa-github"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Project Philosophy -->
            <div class="card" style="margin-top: 3rem;">
                <div class="card-header">
                    <h2>Our Development Philosophy</h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem;">
                        <div>
                            <i class="fas fa-shield-alt" style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                            <h3 style="margin-bottom: 0.5rem;">Security First</h3>
                            <p style="color: var(--text-light);">We prioritize security in every aspect of development, from password encryption to SQL injection prevention.</p>
                        </div>
                        <div>
                            <i class="fas fa-universal-access" style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                            <h3 style="margin-bottom: 0.5rem;">Accessibility</h3>
                            <p style="color: var(--text-light);">Our platform is designed to be accessible to all users, including those with disabilities, following WCAG guidelines.</p>
                        </div>
                        <div>
                            <i class="fas fa-mobile-alt" style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                            <h3 style="margin-bottom: 0.5rem;">Responsive Design</h3>
                            <p style="color: var(--text-light);">The application works seamlessly across all devices, from desktop computers to mobile phones.</p>
                        </div>
                        <div>
                            <i class="fas fa-code" style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                            <h3 style="margin-bottom: 0.5rem;">Clean Code</h3>
                            <p style="color: var(--text-light);">We write maintainable, well-documented code following best practices and industry standards.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Technologies Used -->
            <div class="card" style="margin-top: 2rem;">
                <div class="card-header">
                    <h2>Technologies Used</h2>
                </div>
                <div class="card-body">
                    <div style="display: flex; flex-wrap: wrap; gap: 1rem; justify-content: center;">
                        <span style="padding: 0.5rem 1.5rem; background: var(--primary-color); color: white; border-radius: 20px;">PHP</span>
                        <span style="padding: 0.5rem 1.5rem; background: var(--primary-color); color: white; border-radius: 20px;">MySQL</span>
                        <span style="padding: 0.5rem 1.5rem; background: var(--primary-color); color: white; border-radius: 20px;">JavaScript</span>
                        <span style="padding: 0.5rem 1.5rem; background: var(--primary-color); color: white; border-radius: 20px;">HTML5</span>
                        <span style="padding: 0.5rem 1.5rem; background: var(--primary-color); color: white; border-radius: 20px;">CSS3</span>
                        <span style="padding: 0.5rem 1.5rem; background: var(--primary-color); color: white; border-radius: 20px;">PDO</span>
                        <span style="padding: 0.5rem 1.5rem; background: var(--primary-color); color: white; border-radius: 20px;">Font Awesome</span>
                        <span style="padding: 0.5rem 1.5rem; background: var(--primary-color); color: white; border-radius: 20px;">Bootstrap</span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>
