<?php
$page_title = 'Latest News';
require_once 'includes/config.php';
require_once 'includes/functions.php';

$pdo = db();

// Get page number
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 6;
$offset = ($page - 1) * $per_page;

// Get total count
$total_stmt = $pdo->query("SELECT COUNT(*) as total FROM blog_posts WHERE is_published = 1");
$total_posts = $total_stmt->fetch()['total'];
$total_pages = ceil($total_posts / $per_page);

// Get blog posts
$stmt = $pdo->prepare("SELECT * FROM blog_posts WHERE is_published = 1 ORDER BY created_at DESC LIMIT ? OFFSET ?");
$stmt->execute([$per_page, $offset]);
$posts = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Latest news and updates about plastic pollution and our activities">
    <title>Latest News - PlasticPollutions</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <h1 style="text-align: center; margin-bottom: 1rem; color: var(--primary-color);">Latest on Plastic</h1>
            <p style="text-align: center; max-width: 800px; margin: 0 auto 3rem; color: var(--text-light);">
                Stay updated with the latest news, research, and activities related to plastic pollution and our environmental initiatives.
            </p>
            
            <?php if (empty($posts)): ?>
                <div class="card">
                    <div class="card-body" style="text-align: center; padding: 3rem;">
                        <i class="fas fa-newspaper" style="font-size: 3rem; color: var(--text-light); margin-bottom: 1rem;"></i>
                        <h3>No Articles Yet</h3>
                        <p style="color: var(--text-light);">Check back soon for the latest updates!</p>
                    </div>
                </div>
            <?php else: ?>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 2rem; margin-bottom: 3rem;">
                    <?php foreach ($posts as $post): ?>
                    <article class="card">
                        <?php if ($post['featured_image']): ?>
                        <img src="<?php echo htmlspecialchars($post['featured_image']); ?>" 
                             alt="<?php echo htmlspecialchars($post['title']); ?>" 
                             style="width: 100%; height: 200px; object-fit: cover;">
                        <?php else: ?>
                        <div style="width: 100%; height: 200px; background: var(--primary-light); display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-leaf" style="font-size: 4rem; color: white;"></i>
                        </div>
                        <?php endif; ?>
                        
                        <div class="card-body">
                            <div style="margin-bottom: 1rem;">
                                <span style="background: var(--primary-color); color: white; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.8rem;">
                                    <?php echo htmlspecialchars($post['category'] ?? 'News'); ?>
                                </span>
                                <span style="color: var(--text-light); font-size: 0.875rem; margin-left: 0.5rem;">
                                    <i class="far fa-calendar"></i> <?php echo date('M d, Y', strtotime($post['created_at'])); ?>
                                </span>
                            </div>
                            
                            <h3 style="margin-bottom: 0.75rem; font-size: 1.25rem;">
                                <?php echo htmlspecialchars($post['title']); ?>
                            </h3>
                            
                            <p style="color: var(--text-light); margin-bottom: 1.5rem; line-height: 1.6;">
                                <?php echo htmlspecialchars($post['excerpt'] ?? substr(strip_tags($post['content']), 0, 150) . '...'); ?>
                            </p>
                            
                            <a href="blog-post.php?id=<?php echo $post['id']; ?>" class="btn btn-outline">Read More</a>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                <div style="display: flex; justify-content: center; gap: 0.5rem; flex-wrap: wrap;">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>" class="btn btn-outline">
                            <i class="fas fa-chevron-left"></i> Previous
                        </a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="btn btn-primary" style="cursor: default;"><?php echo $i; ?></span>
                        <?php else: ?>
                            <a href="?page=<?php echo $i; ?>" class="btn btn-outline"><?php echo $i; ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?php echo $page + 1; ?>" class="btn btn-outline">
                            Next <i class="fas fa-chevron-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </section>
    
    <!-- Newsletter Section -->
    <section class="section" style="padding: 4rem 0; background: var(--primary-dark); color: white;">
        <div class="container" style="text-align: center;">
            <h2 style="margin-bottom: 1rem;">Stay Informed</h2>
            <p style="margin-bottom: 2rem; opacity: 0.9;">Subscribe to our newsletter for the latest updates on plastic pollution and our activities.</p>
            <form style="max-width: 500px; margin: 0 auto; display: flex; gap: 0.5rem; flex-wrap: wrap;">
                <input type="email" placeholder="Enter your email" class="form-control" style="flex: 1; min-width: 200px;" required>
                <button type="submit" class="btn" style="background: white; color: var(--primary-dark);">Subscribe</button>
            </form>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>
