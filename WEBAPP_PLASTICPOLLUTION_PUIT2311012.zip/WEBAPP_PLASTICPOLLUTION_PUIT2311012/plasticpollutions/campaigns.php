<?php
$page_title = 'Our Campaigns';
require_once 'includes/config.php';
require_once 'includes/functions.php';

$pdo = db();
$campaigns = $pdo->query("SELECT * FROM campaigns ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn about PlasticPollutions campaigns and their impact">
    <title>Our Campaigns - PlasticPollutions</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <h1 style="text-align: center; margin-bottom: 1rem; color: var(--primary-color);">Our Campaigns</h1>
            <p style="text-align: center; max-width: 800px; margin: 0 auto 3rem; color: var(--text-light);">
                Discover our ongoing and completed campaigns aimed at reducing plastic pollution and creating lasting environmental change.
            </p>
            
            <?php if (empty($campaigns)): ?>
                <div class="card">
                    <div class="card-body" style="text-align: center; padding: 3rem;">
                        <i class="fas fa-bullhorn" style="font-size: 3rem; color: var(--text-light); margin-bottom: 1rem;"></i>
                        <h3>No Campaigns Yet</h3>
                        <p style="color: var(--text-light);">Check back soon for information about our campaigns!</p>
                    </div>
                </div>
            <?php else: ?>
                <?php foreach ($campaigns as $campaign): ?>
                <div class="card" style="margin-bottom: 3rem;">
                    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
                        <h2><?php echo htmlspecialchars($campaign['title']); ?></h2>
                        <span class="badge" style="padding: 0.5rem 1rem; border-radius: 20px; font-size: 0.875rem; background: <?php 
                            echo match($campaign['status']) {
                                'active' => 'var(--success)',
                                'completed' => 'var(--primary-color)',
                                'planning' => 'var(--warning)',
                                'cancelled' => 'var(--danger)',
                                default => 'var(--text-light)'
                            };
                        ?>; color: white;">
                            <?php echo ucfirst($campaign['status']); ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <?php if ($campaign['featured_image']): ?>
                        <img src="<?php echo htmlspecialchars($campaign['featured_image']); ?>" 
                             alt="<?php echo htmlspecialchars($campaign['title']); ?>" 
                             style="width: 100%; max-height: 300px; object-fit: cover; border-radius: var(--border-radius); margin-bottom: 1.5rem;">
                        <?php endif; ?>
                        
                        <p style="margin-bottom: 1.5rem; line-height: 1.8;"><?php echo htmlspecialchars($campaign['description']); ?></p>
                        
                        <?php if ($campaign['goal']): ?>
                        <div style="margin-bottom: 1.5rem;">
                            <strong>Goal:</strong> <?php echo htmlspecialchars($campaign['goal']); ?>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($campaign['start_date'] || $campaign['end_date']): ?>
                        <div style="margin-bottom: 1.5rem;">
                            <strong>Duration:</strong> 
                            <?php 
                            if ($campaign['start_date']) echo date('M d, Y', strtotime($campaign['start_date']));
                            if ($campaign['start_date'] && $campaign['end_date']) echo ' - ';
                            if ($campaign['end_date']) echo date('M d, Y', strtotime($campaign['end_date']));
                            ?>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($campaign['impact_metrics']): ?>
                        <div style="background: var(--bg-light); padding: 1.5rem; border-radius: var(--border-radius);">
                            <h3 style="color: var(--primary-color); margin-bottom: 1rem;">Impact Metrics</h3>
                            <?php
                            $metrics = json_decode($campaign['impact_metrics'], true);
                            if ($metrics && is_array($metrics)):
                            ?>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem;">
                                <?php foreach ($metrics as $key => $value): ?>
                                <div style="text-align: center; padding: 1rem; background: white; border-radius: var(--border-radius);">
                                    <div style="font-size: 1.5rem; font-weight: bold; color: var(--primary-color);">
                                        <?php echo number_format($value); ?>
                                    </div>
                                    <div style="font-size: 0.875rem; color: var(--text-light);">
                                        <?php echo ucfirst(str_replace('_', ' ', $key)); ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
            
            <!-- Get Involved -->
            <div class="card" style="background: linear-gradient(135deg, var(--primary-dark), var(--primary-color)); color: white;">
                <div class="card-body" style="text-align: center;">
                    <h2 style="margin-bottom: 1rem;">Join Our Campaigns</h2>
                    <p style="margin-bottom: 2rem; opacity: 0.9;">Be part of the solution. Volunteer, donate, or spread the word about our campaigns.</p>
                    <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                        <a href="help.php" class="btn" style="background: white; color: var(--primary-color);">Volunteer</a>
                        <a href="donate.php" class="btn btn-outline" style="color: white; border-color: white;">Donate</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>
