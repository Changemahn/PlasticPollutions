<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $petition_id = intval($_POST['petition_id'] ?? 0);
    $user_id = $_SESSION['user_id'];
    
    try {
        $pdo = db();
        
        // Check if already signed
        $stmt = $pdo->prepare("SELECT * FROM petition_signatures WHERE petition_id = ? AND user_id = ?");
        $stmt->execute([$petition_id, $user_id]);
        
        if ($stmt->rowCount() > 0) {
            set_flash_message('error', 'You have already signed this petition');
        } else {
            // Add signature
            $stmt = $pdo->prepare("INSERT INTO petition_signatures (petition_id, user_id) VALUES (?, ?)");
            $stmt->execute([$petition_id, $user_id]);
            
            // Update petition count
            $stmt = $pdo->prepare("UPDATE petitions SET current_signatures = current_signatures + 1 WHERE id = ?");
            $stmt->execute([$petition_id]);
            
            set_flash_message('success', 'Thank you for signing the petition!');
        }
    } catch (Exception $e) {
        set_flash_message('error', 'Failed to sign petition: ' . $e->getMessage());
    }
    
    header('Location: what-to-do.php');
    exit;
}
?>
