<?php
$page_title = 'Contact Us';
require_once 'includes/config.php';
require_once 'includes/functions.php';

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize_input($_POST['name'] ?? '');
    $email = sanitize_input($_POST['email'] ?? '');
    $subject = sanitize_input($_POST['subject'] ?? '');
    $message = sanitize_input($_POST['message'] ?? '');
    
    // Validation
    if (empty($name)) {
        $errors[] = "Name is required";
    } elseif (!preg_match("/^[a-zA-Z\s]{2,100}$/", $name)) {
        $errors[] = "Name must be 2-100 letters only";
    }
    
    if (empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    
    if (empty($subject)) {
        $errors[] = "Subject is required";
    } elseif (strlen($subject) < 5 || strlen($subject) > 200) {
        $errors[] = "Subject must be 5-200 characters";
    }
    
    if (empty($message)) {
        $errors[] = "Message is required";
    } elseif (strlen($message) < 10 || strlen($message) > 5000) {
        $errors[] = "Message must be 10-5000 characters";
    }
    
    if (empty($errors)) {
        try {
            $pdo = db();
            $stmt = $pdo->prepare("INSERT INTO contact_messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $email, $subject, $message]);
            
            $success = true;
            set_flash_message('success', 'Your message has been sent successfully! We will get back to you soon.');
        } catch (Exception $e) {
            $errors[] = "Failed to send message: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Contact PlasticPollutions - Send us your questions and feedback">
    <title>Contact Us - PlasticPollutions</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <h1 style="text-align: center; margin-bottom: 1rem; color: var(--primary-color);">Contact Us</h1>
            <p style="text-align: center; max-width: 800px; margin: 0 auto 3rem; color: var(--text-light);">
                Have questions or want to get involved? We'd love to hear from you. Send us a message and we'll get back to you as soon as possible.
            </p>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 3rem;">
                <!-- Contact Form -->
                <div class="card">
                    <div class="card-header">
                        <h2>Send a Message</h2>
                    </div>
                    <div class="card-body">
                        <?php if (has_flash_message('success')): ?>
                            <div class="alert alert-success">
                                <?php echo htmlspecialchars(get_flash_message('success')); ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <?php foreach ($errors as $error): ?>
                                    <p><?php echo htmlspecialchars($error); ?></p>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" action="contact.php">
                            <div class="form-group">
                                <label for="name">Your Name *</label>
                                <input type="text" id="name" name="name" class="form-control" 
                                       value="<?php echo htmlspecialchars($name ?? ''); ?>" 
                                       required aria-required="true">
                            </div>
                            
                            <div class="form-group">
                                <label for="email">Email Address *</label>
                                <input type="email" id="email" name="email" class="form-control" 
                                       value="<?php echo htmlspecialchars($email ?? ''); ?>" 
                                       required aria-required="true">
                            </div>
                            
                            <div class="form-group">
                                <label for="subject">Subject *</label>
                                <input type="text" id="subject" name="subject" class="form-control" 
                                       value="<?php echo htmlspecialchars($subject ?? ''); ?>" 
                                       required aria-required="true">
                            </div>
                            
                            <div class="form-group">
                                <label for="message">Message *</label>
                                <textarea id="message" name="message" class="form-control" rows="6" 
                                          required aria-required="true"><?php echo htmlspecialchars($message ?? ''); ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-block">Send Message</button>
                        </form>
                    </div>
                </div>
                
                <!-- Contact Information -->
                <div>
                    <div class="card" style="margin-bottom: 2rem;">
                        <div class="card-header">
                            <h2>Contact Information</h2>
                        </div>
                        <div class="card-body">
                            <div style="margin-bottom: 1.5rem;">
                                <i class="fas fa-map-marker-alt" style="color: var(--primary-color); font-size: 1.5rem; margin-right: 1rem;"></i>
                                <div style="display: inline-block; vertical-align: top;">
                                    <strong>Address:</strong><br>
                                    Pentecost University<br>
                                    Accra, Ghana
                                </div>
                            </div>
                            
                            <div style="margin-bottom: 1.5rem;">
                                <i class="fas fa-envelope" style="color: var(--primary-color); font-size: 1.5rem; margin-right: 1rem;"></i>
                                <div style="display: inline-block; vertical-align: top;">
                                    <strong>Email:</strong><br>
                                    <?php echo SITE_EMAIL; ?>
                                </div>
                            </div>
                            
                            <div style="margin-bottom: 1.5rem;">
                                <i class="fas fa-phone" style="color: var(--primary-color); font-size: 1.5rem; margin-right: 1rem;"></i>
                                <div style="display: inline-block; vertical-align: top;">
                                    <strong>Phone:</strong><br>
                                    +233 530096029
                                </div>
                            </div>
                            
                            <div>
                                <i class="fas fa-clock" style="color: var(--primary-color); font-size: 1.5rem; margin-right: 1rem;"></i>
                                <div style="display: inline-block; vertical-align: top;">
                                    <strong>Office Hours:</strong><br>
                                    Monday - Friday: 9:00 AM - 5:00 PM
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Map -->
                    <div class="card">
                        <div class="card-header">
                            <h2>Find Us</h2>
                        </div>
                        <div class="card-body">
                         <iframe
  src="https://www.google.com/maps/embed?q=Pentecost+University,Sowutoum,Accra,Ghana"
  width="100%"
  height="250px"
  style="border:0;"
  allowfullscreen=""
  loading="lazy">
</iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
    <script src="js/contact.js"></script>
</body>
</html>
