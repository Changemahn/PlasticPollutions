<?php
$page_title = 'Our Strategy';
require_once 'includes/config.php';
require_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn about PlasticPollutions strategy to tackle plastic pollution">
    <title>Our Strategy - PlasticPollutions</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <h1 style="text-align: center; margin-bottom: 1rem; color: var(--primary-color);">Our Strategy</h1>
            <p style="text-align: center; max-width: 800px; margin: 0 auto 3rem; color: var(--text-light);">
                Our comprehensive approach to tackling plastic pollution through education, advocacy, community action, and policy change.
            </p>
            
            <!-- Vision and Mission -->
            <div class="card" style="margin-bottom: 3rem;">
                <div class="card-header">
                    <h2>Vision & Mission</h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem;">
                        <div style="text-align: center; padding: 2rem; background: var(--bg-light); border-radius: var(--border-radius);">
                            <i class="fas fa-eye" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                            <h3 style="margin-bottom: 1rem;">Our Vision</h3>
                            <p style="color: var(--text-light); line-height: 1.8;">
                                A Ghana free from plastic pollution where our oceans, rivers, and land are protected for future generations. We envision a society that embraces sustainable practices and responsible consumption.
                            </p>
                        </div>
                        <div style="text-align: center; padding: 2rem; background: var(--bg-light); border-radius: var(--border-radius);">
                            <i class="fas fa-bullseye" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                            <h3 style="margin-bottom: 1rem;">Our Mission</h3>
                            <p style="color: var(--text-light); line-height: 1.8;">
                                To reduce plastic waste through education, advocacy, and community action. We work to raise awareness, promote recycling, and influence policy to create lasting environmental change.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Strategic Goals -->
            <div class="card" style="margin-bottom: 3rem;">
                <div class="card-header">
                    <h2>Strategic Goals</h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem;">
                        <div style="padding: 1.5rem; border-left: 4px solid var(--primary-color); background: var(--bg-light);">
                            <h3 style="color: var(--primary-color); margin-bottom: 0.5rem;">
                                <i class="fas fa-graduation-cap"></i> Education
                            </h3>
                            <p style="color: var(--text-light);">Educate 10,000 students and community members about plastic pollution and recycling by 2026.</p>
                        </div>
                        <div style="padding: 1.5rem; border-left: 4px solid var(--primary-color); background: var(--bg-light);">
                            <h3 style="color: var(--primary-color); margin-bottom: 0.5rem;">
                                <i class="fas fa-broom"></i> Cleanups
                            </h3>
                            <p style="color: var(--text-light);">Organize 50 cleanup events removing 100 tons of plastic waste from Ghanaian waterways and communities.</p>
                        </div>
                        <div style="padding: 1.5rem; border-left: 4px solid var(--primary-color); background: var(--bg-light);">
                            <h3 style="color: var(--primary-color); margin-bottom: 0.5rem;">
                                <i class="fas fa-recycle"></i> Recycling
                            </h3>
                            <p style="color: var(--text-light);">Establish partnerships with recycling facilities and create convenient drop-off points across the university community.</p>
                        </div>
                        <div style="padding: 1.5rem; border-left: 4px solid var(--primary-color); background: var(--bg-light);">
                            <h3 style="color: var(--primary-color); margin-bottom: 0.5rem;">
                                <i class="fas fa-balance-scale"></i> Advocacy
                            </h3>
                            <p style="color: var(--text-light);">Advocate for policies that reduce single-use plastics and promote sustainable alternatives at institutional and governmental levels.</p>
                        </div>
                        <div style="padding: 1.5rem; border-left: 4px solid var(--primary-color); background: var(--bg-light);">
                            <h3 style="color: var(--primary-color); margin-bottom: 0.5rem;">
                                <i class="fas fa-users"></i> Community
                            </h3>
                            <p style="color: var(--text-light);">Build a community of 5,000 active members committed to reducing their plastic footprint and promoting sustainable practices.</p>
                        </div>
                        <div style="padding: 1.5rem; border-left: 4px solid var(--primary-color); background: var(--bg-light);">
                            <h3 style="color: var(--primary-color); margin-bottom: 0.5rem;">
                                <i class="fas fa-handshake"></i> Partnerships
                            </h3>
                            <p style="color: var(--text-light);">Partner with 20 organizations, businesses, and government agencies to amplify our impact and reach.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Our Approach -->
            <div class="card" style="margin-bottom: 3rem;">
                <div class="card-header">
                    <h2>Our Approach</h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem;">
                        <div>
                            <h3 style="color: var(--primary-color); margin-bottom: 1rem;">
                                <i class="fas fa-chalkboard-teacher"></i> Awareness & Education
                            </h3>
                            <ul style="line-height: 2; color: var(--text-light);">
                                <li>Workshops and seminars on plastic pollution</li>
                                <li>Social media awareness campaigns</li>
                                <li>Educational materials and resources</li>
                                <li>School and university programs</li>
                                <li>Community outreach initiatives</li>
                            </ul>
                        </div>
                        <div>
                            <h3 style="color: var(--primary-color); margin-bottom: 1rem;">
                                <i class="fas fa-hands-helping"></i> Direct Action
                            </h3>
                            <ul style="line-height: 2; color: var(--text-light);">
                                <li>Regular beach and river cleanups</li>
                                <li>Community waste collection drives</li>
                                <li>Tree planting and restoration projects</li>
                                <li>Plastic waste sorting and recycling</li>
                                <li>Volunteer mobilization programs</li>
                            </ul>
                        </div>
                        <div>
                            <h3 style="color: var(--primary-color); margin-bottom: 1rem;">
                                <i class="fas fa-landmark"></i> Policy & Advocacy
                            </h3>
                            <ul style="line-height: 2; color: var(--text-light);">
                                <li>Petition drives for policy change</li>
                                <li>Engagement with local government</li>
                                <li>Research and data collection</li>
                                <li>Policy recommendation papers</li>
                                <li>Collaboration with environmental agencies</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Timeline -->
            <div class="card">
                <div class="card-header">
                    <h2>Implementation Timeline</h2>
                </div>
                <div class="card-body">
                    <div style="position: relative; padding-left: 2rem;">
                        <div style="position: absolute; left: 0; top: 0; bottom: 0; width: 2px; background: var(--primary-color);"></div>
                        
                        <div style="margin-bottom: 2rem; position: relative;">
                            <div style="position: absolute; left: -2.4rem; top: 0; width: 1rem; height: 1rem; background: var(--primary-color); border-radius: 50%;"></div>
                            <h3 style="color: var(--primary-color);">Phase 1: Foundation (Q1 2025)</h3>
                            <p style="color: var(--text-light);">Establish core team, develop partnerships, launch awareness campaign, organize first cleanup events.</p>
                        </div>
                        
                        <div style="margin-bottom: 2rem; position: relative;">
                            <div style="position: absolute; left: -2.4rem; top: 0; width: 1rem; height: 1rem; background: var(--primary-color); border-radius: 50%;"></div>
                            <h3 style="color: var(--primary-color);">Phase 2: Expansion (Q2-Q3 2025)</h3>
                            <p style="color: var(--text-light);">Scale up cleanup operations, launch recycling program, expand educational outreach, begin policy advocacy.</p>
                        </div>
                        
                        <div style="margin-bottom: 2rem; position: relative;">
                            <div style="position: absolute; left: -2.4rem; top: 0; width: 1rem; height: 1rem; background: var(--primary-color); border-radius: 50%;"></div>
                            <h3 style="color: var(--primary-color);">Phase 3: Impact (Q4 2025)</h3>
                            <p style="color: var(--text-light);">Evaluate progress, document impact, refine strategies, prepare for year 2 expansion, celebrate achievements.</p>
                        </div>
                        
                        <div style="position: relative;">
                            <div style="position: absolute; left: -2.4rem; top: 0; width: 1rem; height: 1rem; background: var(--primary-color); border-radius: 50%;"></div>
                            <h3 style="color: var(--primary-color);">Phase 4: Sustainability (2026+)</h3>
                            <p style="color: var(--text-light);">Establish long-term programs, secure sustainable funding, influence national policy, become a model for other institutions.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>
