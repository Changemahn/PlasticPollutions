-- PlasticPollutions Database Schema
-- Created for Pentecost University Environmental Action Group

-- Create database
CREATE DATABASE IF NOT EXISTS plasticpollutions CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE plasticpollutions;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    visitor_id VARCHAR(8) UNIQUE NOT NULL COMMENT 'PU + 6 digits',
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (email),
    INDEX (visitor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Login attempts table for security
CREATE TABLE IF NOT EXISTS login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    attempt_count INT DEFAULT 1,
    lockout_until TIMESTAMP NULL,
    last_attempt_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Donations table
CREATE TABLE IF NOT EXISTS donations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    donation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    payment_method VARCHAR(50) DEFAULT 'card',
    status ENUM('pending', 'completed', 'failed') DEFAULT 'completed',
    notes TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX (user_id),
    INDEX (donation_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Petitions table
CREATE TABLE IF NOT EXISTS petitions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    target_signatures INT DEFAULT 1000,
    current_signatures INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Petition signatures
CREATE TABLE IF NOT EXISTS petition_signatures (
    id INT AUTO_INCREMENT PRIMARY KEY,
    petition_id INT NOT NULL,
    user_id INT NOT NULL,
    signed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (petition_id) REFERENCES petitions(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_signature (petition_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Pledges table
CREATE TABLE IF NOT EXISTS pledges (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    pledge_type VARCHAR(100) NOT NULL,
    description TEXT,
    pledge_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('active', 'completed', 'cancelled') DEFAULT 'active',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Blog posts table (Latest on Plastic)
CREATE TABLE IF NOT EXISTS blog_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    content TEXT NOT NULL,
    excerpt VARCHAR(500),
    featured_image VARCHAR(255),
    video_url VARCHAR(500),
    author_id INT,
    category VARCHAR(100),
    is_published TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX (slug),
    INDEX (is_published)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Campaigns table
CREATE TABLE IF NOT EXISTS campaigns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    goal VARCHAR(255),
    start_date DATE,
    end_date DATE,
    impact_metrics JSON,
    status ENUM('planning', 'active', 'completed', 'cancelled') DEFAULT 'planning',
    featured_image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Contact messages table
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Visitors table for tracking
CREATE TABLE IF NOT EXISTS visitors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45),
    visit_date DATE NOT NULL,
    page_views INT DEFAULT 1,
    last_visit TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_visit (ip_address, visit_date),
    INDEX (visit_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Site settings table (for admin)
CREATE TABLE IF NOT EXISTS site_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admin user (password: Admin@123)
-- Password hashed using bcrypt
INSERT INTO users (visitor_id, first_name, last_name, email, password, role) VALUES 
('PU000001', 'Admin', 'User', 'admin@plasticpollutions.org', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin')
ON DUPLICATE KEY UPDATE email=email;

-- Insert default site settings
INSERT INTO site_settings (setting_key, setting_value) VALUES
('site_name', 'PlasticPollutions'),
('site_description', 'Environmental action group at Pentecost University'),
('contact_email', 'info@plasticpollutions.org'),
('visitor_count', '0')
ON DUPLICATE KEY UPDATE setting_key=setting_key;

-- Insert sample petition
INSERT INTO petitions (title, description, target_signatures) VALUES
('Ban Single-Use Plastics in Ghana', 'Join us in petitioning the Ghanaian government to ban single-use plastics and promote sustainable alternatives. Together, we can make a difference for our environment and future generations.', 5000)
ON DUPLICATE KEY UPDATE title=title;

-- Insert sample blog posts
INSERT INTO blog_posts (title, slug, content, excerpt, featured_image, video_url, category, is_published) VALUES
('The Impact of Plastic on Marine Life', 'impact-of-plastic-on-marine-life', 
'Plastic pollution is one of the greatest threats to marine ecosystems worldwide. Every year, millions of tons of plastic waste end up in our oceans, harming marine life and disrupting fragile ecosystems. Sea turtles mistake plastic bags for jellyfish, whales ingest microplastics, and coral reefs are smothered by plastic debris. The PlasticPollutions group is committed to raising awareness about these issues and implementing solutions to reduce plastic waste.',
'Learn about the devastating effects of plastic pollution on marine ecosystems and what we can do to help.',
'images/ocean-pollu.jpg', '', 'Environment', 1),
('Successful Beach Cleanup at Labadi', 'successful-beach-cleanup-labadi',
'Last Saturday, our PlasticPollutions team organized a massive beach cleanup event at Labadi Beach. Over 150 volunteers participated, collecting more than 2 tons of plastic waste and other debris from the shoreline. The event was a huge success, with support from local businesses and community members. We found everything from plastic bottles and bags to abandoned fishing nets. This cleanup not only helped restore the beauty of our beach but also protected marine life from harmful plastic debris.',
'Join us as we celebrate our successful beach cleanup event that removed 2 tons of plastic waste from Labadi Beach.',
'images/beach-cleanup.jpg', 'videos/cleanup-event.mp4', 'Events', 1),
('Innovative Recycling Solutions in Ghana', 'innovative-recycling-ghana',
'Ghana is leading the way in innovative recycling solutions for plastic waste. Local entrepreneurs are creating amazing products from recycled plastics, including building materials, furniture, and even art installations. One company in Accra is turning plastic bottles into durable construction blocks, while another is creating beautiful jewelry from ocean plastic. These innovations not only reduce waste but also create jobs and economic opportunities for Ghanaian communities.',
'Discover how Ghanaian entrepreneurs are transforming plastic waste into valuable products and creating sustainable businesses.',
'images/recycling-bin.jpg', '', 'Innovation', 1),
('Student-Led Plastic Reduction Campaign', 'student-plastic-campaign',
'Pentecost University students have launched an inspiring campaign to reduce single-use plastics on campus. The campaign includes educational workshops, reusable water bottle distribution, and a plastic-free challenge that has already reduced campus plastic waste by 40%. Students have also designed creative awareness posters and organized social media campaigns that have reached thousands of people. This initiative shows how young people can lead meaningful environmental change.',
'Learn how Pentecost University students are leading the charge against plastic pollution with their innovative campus campaign.',
'images/comm-action.jpg', 'videos/student-campaign.mp4', 'Education', 1),
('Microplastics: The Hidden Threat', 'microplastics-hidden-threat',
'Microplastics are tiny plastic particles less than 5mm in size that pose a serious threat to our environment and health. These invisible pollutants are found in our water, food, and even the air we breathe. Recent studies have discovered microplastics in human blood, lungs, and placentas. Our research team is working to understand the full impact of microplastics on human health and develop strategies to reduce our exposure to these harmful particles.',
'Explore the invisible world of microplastics and their impact on human health and the environment.',
'images/plastic-waste.jpg', '', 'Research', 1)
ON DUPLICATE KEY UPDATE slug=slug;

-- Insert sample campaign
INSERT INTO campaigns (title, description, goal, start_date, end_date, status, impact_metrics) VALUES
('Clean Ghana Initiative', 'A nationwide campaign to clean up plastic waste from beaches, rivers, and urban areas. We organize monthly cleanup events and work with local communities to promote proper waste disposal.',
'Remove 100 tons of plastic waste from Ghanaian waterways', '2025-01-01', '2025-12-31', 'active',
'{"volunteers": 500, "waste_collected_kg": 25000, "events": 12}')
ON DUPLICATE KEY UPDATE title=title;
