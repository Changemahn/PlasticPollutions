<?php
$page_title = 'How You Can Help';
require_once 'includes/config.php';
require_once 'includes/functions.php';

$pdo = db();
$errors = [];
$success = false;

// Handle pledge submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pledge_type'])) {
    require_login();
    
    $pledge_type = sanitize_input($_POST['pledge_type'] ?? '');
    $description = sanitize_input($_POST['description'] ?? '');
    
    if (empty($pledge_type)) {
        $errors[] = "Pledge type is required";
    }
    
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO pledges (user_id, pledge_type, description) VALUES (?, ?, ?)");
            $stmt->execute([$_SESSION['user_id'], $pledge_type, $description]);
            $success = true;
            set_flash_message('success', 'Thank you for your pledge! Every commitment makes a difference.');
        } catch (Exception $e) {
            $errors[] = "Failed to save pledge: " . $e->getMessage();
        }
    }
}

// Get user's pledges
$user_pledges = [];
if (is_logged_in()) {
    $stmt = $pdo->prepare("SELECT * FROM pledges WHERE user_id = ? ORDER BY pledge_date DESC");
    $stmt->execute([$_SESSION['user_id']]);
    $user_pledges = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn how you can help reduce plastic pollution">
    <title>How You Can Help - PlasticPollutions</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <h1 style="text-align: center; margin-bottom: 1rem; color: var(--primary-color);">How You Can Help</h1>
            <p style="text-align: center; max-width: 800px; margin: 0 auto 3rem; color: var(--text-light);">
                Every action counts. Discover practical ways you can contribute to reducing plastic pollution and creating a sustainable future.
            </p>
            
            <!-- Ways to Help -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; margin-bottom: 3rem;">
                <div class="card">
                    <div class="card-body" style="text-align: center;">
                        <i class="fas fa-hands-helping" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                        <h3 style="margin-bottom: 1rem;">Volunteer</h3>
                        <p style="color: var(--text-light); margin-bottom: 1.5rem;">Join our cleanup events, help with educational programs, or assist with administrative tasks.</p>
                        <a href="contact.php" class="btn btn-primary">Sign Up to Volunteer</a>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-body" style="text-align: center;">
                        <i class="fas fa-donate" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                        <h3 style="margin-bottom: 1rem;">Donate</h3>
                        <p style="color: var(--text-light); margin-bottom: 1.5rem;">Support our campaigns and initiatives with a financial contribution. Every amount helps.</p>
                        <a href="donate.php" class="btn btn-primary">Make a Donation</a>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-body" style="text-align: center;">
                        <i class="fas fa-bullhorn" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                        <h3 style="margin-bottom: 1rem;">Spread the Word</h3>
                        <p style="color: var(--text-light); margin-bottom: 1.5rem;">Share our message on social media, tell your friends, and help raise awareness.</p>
                        <a href="#" class="btn btn-primary">Share Now</a>
                    </div>
                </div>
            </div>
            
            <!-- Lifestyle Changes -->
            <div class="card" style="margin-bottom: 3rem;">
                <div class="card-header">
                    <h2>Lifestyle Changes</h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem;">
                        <div style="padding: 1rem;">
                            <i class="fas fa-shopping-bag" style="color: var(--primary-color); font-size: 1.5rem; margin-right: 0.5rem;"></i>
                            <strong>Bring reusable bags</strong> when shopping
                        </div>
                        <div style="padding: 1rem;">
                            <i class="fas fa-glass-water" style="color: var(--primary-color); font-size: 1.5rem; margin-right: 0.5rem;"></i>
                            <strong>Use a reusable water bottle</strong> instead of single-use plastic
                        </div>
                        <div style="padding: 1rem;">
                            <i class="fas fa-utensils" style="color: var(--primary-color); font-size: 1.5rem; margin-right: 0.5rem;"></i>
                            <strong>Carry reusable utensils</strong> for takeout meals
                        </div>
                        <div style="padding: 1rem;">
                            <i class="fas fa-mug-hot" style="color: var(--primary-color); font-size: 1.5rem; margin-right: 0.5rem;"></i>
                            <strong>Bring your own cup</strong> for coffee and drinks
                        </div>
                        <div style="padding: 1rem;">
                            <i class="fas fa-seedling" style="color: var(--primary-color); font-size: 1.5rem; margin-right: 0.5rem;"></i>
                            <strong>Choose products with minimal packaging</strong>
                        </div>
                        <div style="padding: 1rem;">
                            <i class="fas fa-recycle" style="color: var(--primary-color); font-size: 1.5rem; margin-right: 0.5rem;"></i>
                            <strong>Recycle properly</strong> and learn your local guidelines
                        </div>
                        <div style="padding: 1rem;">
                            <i class="fas fa-ban" style="color: var(--primary-color); font-size: 1.5rem; margin-right: 0.5rem;"></i>
                            <strong>Avoid single-use plastics</strong> like straws and cutlery
                        </div>
                        <div style="padding: 1rem;">
                            <i class="fas fa-soap" style="color: var(--primary-color); font-size: 1.5rem; margin-right: 0.5rem;"></i>
                            <strong>Choose bar soap</strong> instead of liquid in plastic bottles
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Pledge System -->
            <div class="card" style="margin-bottom: 3rem; border: 2px solid var(--primary-color);">
                <div class="card-header" style="background: var(--primary-color);">
                    <h2><i class="fas fa-hand-holding-heart"></i> Make a Pledge</h2>
                </div>
                <div class="card-body">
                    <?php if (has_flash_message('success')): ?>
                        <div class="alert alert-success">
                            <?php echo htmlspecialchars(get_flash_message('success')); ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <?php foreach ($errors as $error): ?>
                                <p><?php echo htmlspecialchars($error); ?></p>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (is_logged_in()): ?>
                        <p style="margin-bottom: 1.5rem;">Commit to making a change. Your pledge will be tracked and you can update your progress.</p>
                        
                        <form method="POST" action="help.php">
                            <div class="form-group">
                                <label for="pledge_type">Choose Your Pledge *</label>
                                <select id="pledge_type" name="pledge_type" class="form-control" required>
                                    <option value="">Select a pledge...</option>
                                    <option value="no_single_use_plastics">I pledge to eliminate single-use plastics</option>
                                    <option value="reusable_items">I pledge to use reusable items daily</option>
                                    <option value="recycle">I pledge to recycle all eligible materials</option>
                                    <option value="spread_awareness">I pledge to spread awareness about plastic pollution</option>
                                    <option value="volunteer">I pledge to volunteer at cleanup events</option>
                                    <option value="custom">I have a custom pledge</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="description">Describe Your Commitment</label>
                                <textarea id="description" name="description" class="form-control" rows="3" placeholder="Tell us about your commitment..."></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Make My Pledge</button>
                        </form>
                        
                        <?php if (!empty($user_pledges)): ?>
                        <div style="margin-top: 2rem;">
                            <h3 style="margin-bottom: 1rem;">Your Pledges</h3>
                            <?php foreach ($user_pledges as $pledge): ?>
                            <div style="padding: 1rem; background: var(--bg-light); border-radius: var(--border-radius); margin-bottom: 0.5rem;">
                                <strong><?php echo htmlspecialchars(str_replace('_', ' ', ucfirst($pledge['pledge_type']))); ?></strong>
                                <span style="float: right; color: var(--text-light); font-size: 0.875rem;">
                                    <?php echo date('M d, Y', strtotime($pledge['pledge_date'])); ?>
                                </span>
                                <?php if ($pledge['description']): ?>
                                <p style="margin: 0.5rem 0 0; color: var(--text-light); font-size: 0.875rem;">
                                    <?php echo htmlspecialchars($pledge['description']); ?>
                                </p>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <p style="margin-bottom: 1rem;">Please login to make a pledge and track your commitments.</p>
                        <a href="login.php" class="btn btn-primary">Login to Pledge</a>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Impact Calculator -->
            <div class="card">
                <div class="card-header">
                    <h2>Your Impact Calculator</h2>
                </div>
                <div class="card-body">
                    <p style="margin-bottom: 1.5rem;">See how small changes add up to make a big difference.</p>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem;">
                        <div style="text-align: center; padding: 1.5rem; background: var(--bg-light); border-radius: var(--border-radius);">
                            <div style="font-size: 2rem; font-weight: bold; color: var(--primary-color);" id="bagsSaved">0</div>
                            <div style="color: var(--text-light);">Plastic Bags Saved/Year</div>
                            <input type="range" min="0" max="365" value="0" class="form-control" style="margin-top: 1rem;" oninput="document.getElementById('bagsSaved').textContent = this.value">
                        </div>
                        <div style="text-align: center; padding: 1.5rem; background: var(--bg-light); border-radius: var(--border-radius);">
                            <div style="font-size: 2rem; font-weight: bold; color: var(--primary-color);" id="bottlesSaved">0</div>
                            <div style="color: var(--text-light);">Bottles Saved/Year</div>
                            <input type="range" min="0" max="365" value="0" class="form-control" style="margin-top: 1rem;" oninput="document.getElementById('bottlesSaved').textContent = this.value">
                        </div>
                        <div style="text-align: center; padding: 1.5rem; background: var(--bg-light); border-radius: var(--border-radius);">
                            <div style="font-size: 2rem; font-weight: bold; color: var(--primary-color);" id="strawsSaved">0</div>
                            <div style="color: var(--text-light);">Straws Saved/Year</div>
                            <input type="range" min="0" max="365" value="0" class="form-control" style="margin-top: 1rem;" oninput="document.getElementById('strawsSaved').textContent = this.value">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>
