<?php
$page_title = 'What to Do About Plastic';
require_once 'includes/config.php';
require_once 'includes/functions.php';

$pdo = db();

// Get petition information
$petition = $pdo->query("SELECT * FROM petitions WHERE is_active = 1 LIMIT 1")->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn about different types of plastics, their environmental impact, and recycling methods">
    <title>What to Do About Plastic - PlasticPollutions</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <h1 style="text-align: center; margin-bottom: 1rem; color: var(--primary-color);">What to Do About Plastic</h1>
            <p style="text-align: center; max-width: 800px; margin: 0 auto 3rem; color: var(--text-light);">
                Understanding plastic types, their impact, and how we can make a difference through recycling and sustainable choices.
            </p>
            
            <!-- Types of Plastics -->
            <div class="card" style="margin-bottom: 3rem;">
                <div class="card-header">
                    <h2>Types of Plastics</h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem;">
                        <div style="padding: 1.5rem; background: var(--bg-light); border-radius: var(--border-radius);">
                            <h3 style="color: var(--primary-color); margin-bottom: 0.5rem;">PET (Polyethylene Terephthalate)</h3>
                            <p style="color: var(--text-light); margin-bottom: 0.5rem;"><strong>Common in:</strong> Water bottles, food containers</p>
                            <p style="color: var(--text-light);"><strong>Recyclable:</strong> Yes - Most commonly recycled</p>
                        </div>
                        <div style="padding: 1.5rem; background: var(--bg-light); border-radius: var(--border-radius);">
                            <h3 style="color: var(--primary-color); margin-bottom: 0.5rem;">HDPE (High-Density Polyethylene)</h3>
                            <p style="color: var(--text-light); margin-bottom: 0.5rem;"><strong>Common in:</strong> Milk jugs, detergent bottles</p>
                            <p style="color: var(--text-light);"><strong>Recyclable:</strong> Yes - Widely accepted</p>
                        </div>
                        <div style="padding: 1.5rem; background: var(--bg-light); border-radius: var(--border-radius);">
                            <h3 style="color: var(--primary-color); margin-bottom: 0.5rem;">PVC (Polyvinyl Chloride)</h3>
                            <p style="color: var(--text-light); margin-bottom: 0.5rem;"><strong>Common in:</strong> Pipes, credit cards</p>
                            <p style="color: var(--text-light);"><strong>Recyclable:</strong> Rarely - Limited facilities</p>
                        </div>
                        <div style="padding: 1.5rem; background: var(--bg-light); border-radius: var(--border-radius);">
                            <h3 style="color: var(--primary-color); margin-bottom: 0.5rem;">LDPE (Low-Density Polyethylene)</h3>
                            <p style="color: var(--text-light); margin-bottom: 0.5rem;"><strong>Common in:</strong> Plastic bags, shrink wrap</p>
                            <p style="color: var(--text-light);"><strong>Recyclable:</strong> Sometimes - Drop-off locations</p>
                        </div>
                        <div style="padding: 1.5rem; background: var(--bg-light); border-radius: var(--border-radius);">
                            <h3 style="color: var(--primary-color); margin-bottom: 0.5rem;">PP (Polypropylene)</h3>
                            <p style="color: var(--text-light); margin-bottom: 0.5rem;"><strong>Common in:</strong> Yogurt containers, bottle caps</p>
                            <p style="color: var(--text-light);"><strong>Recyclable:</strong> Yes - Becoming more common</p>
                        </div>
                        <div style="padding: 1.5rem; background: var(--bg-light); border-radius: var(--border-radius);">
                            <h3 style="color: var(--primary-color); margin-bottom: 0.5rem;">PS (Polystyrene)</h3>
                            <p style="color: var(--text-light); margin-bottom: 0.5rem;"><strong>Common in:</strong> Foam cups, packaging</p>
                            <p style="color: var(--text-light);"><strong>Recyclable:</strong> Rarely - Very limited</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Environmental Impact -->
            <div class="card" style="margin-bottom: 3rem;">
                <div class="card-header">
                    <h2>Environmental Impact</h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem;">
                        <div>
                            <img src="images/ocean-pollu.jpg" alt="Ocean pollution" style="width: 100%; border-radius: var(--border-radius); margin-bottom: 1rem;">
                            <h3 style="color: var(--primary-color);">Ocean Pollution</h3>
                            <p style="color: var(--text-light);">Over 8 million tons of plastic enter our oceans annually, harming marine life and ecosystems. Sea turtles, whales, and countless other species suffer from ingestion and entanglement.</p>
                        </div>
                        <div>
                            <img src="images/land-pollu.jpg" alt="Land pollution" style="width: 100%; border-radius: var(--border-radius); margin-bottom: 1rem;">
                            <h3 style="color: var(--primary-color);">Land Pollution</h3>
                            <p style="color: var(--text-light);">Plastic waste in landfills can take hundreds of years to decompose. Microplastics contaminate soil and groundwater, affecting agriculture and drinking water sources.</p>
                        </div>
                        <div>
                            <img src="images/wildlife-impact.jpg" alt="Wildlife impact" style="width: 100%; border-radius: var(--border-radius); margin-bottom: 1rem;">
                            <h3 style="color: var(--primary-color);">Wildlife Impact</h3>
                            <p style="color: var(--text-light);">Over 1 million marine animals die each year due to plastic pollution. Birds, fish, and land animals mistake plastic for food, leading to starvation and death.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recycling Methods -->
            <div class="card" style="margin-bottom: 3rem;">
                <div class="card-header">
                    <h2>Recycling Methods</h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem;">
                        <div style="text-align: center; padding: 1.5rem;">
                            <i class="fas fa-recycle" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                            <h3 style="margin-bottom: 0.5rem;">Curbside Recycling</h3>
                            <p style="color: var(--text-light);">Many areas offer curbside pickup for recyclable plastics. Check your local guidelines for accepted materials.</p>
                        </div>
                        <div style="text-align: center; padding: 1.5rem;">
                            <i class="fas fa-map-marker-alt" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                            <h3 style="margin-bottom: 0.5rem;">Drop-off Centers</h3>
                            <p style="color: var(--text-light);">Local recycling centers accept various plastics. Find locations near you for items not accepted curbside.</p>
                        </div>
                        <div style="text-align: center; padding: 1.5rem;">
                            <i class="fas fa-store" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                            <h3 style="margin-bottom: 0.5rem;">Store Programs</h3>
                            <p style="color: var(--text-light);">Many grocery stores have bag recycling bins. Some retailers accept specific packaging for recycling.</p>
                        </div>
                        <div style="text-align: center; padding: 1.5rem;">
                            <i class="fas fa-tools" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                            <h3 style="margin-bottom: 0.5rem;">Upcycling</h3>
                            <p style="color: var(--text-light);">Get creative! Repurpose plastic containers for storage, crafts, or DIY projects instead of throwing them away.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Video Section -->
            <div class="card" style="margin-bottom: 3rem;">
                <div class="card-header">
                    <h2>Educational Video</h2>
                </div>
                <div class="card-body">
                    <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; border-radius: var(--border-radius);">
                        <iframe style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;" 
                                src="https://www.youtube.com/embed/HQTUWK7CM-Y" 
                                title="Understanding Plastic Pollution"
                                frameborder="0" 
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                                allowfullscreen>
                        </iframe>
                    </div>
                    <p style="margin-top: 1rem; color: var(--text-light); text-align: center;">
                        Watch this educational video to learn more about plastic pollution and what we can do to help.
                    </p>
                </div>
            </div>
            
            <!-- Petition Section -->
            <?php if ($petition): ?>
            <div class="card" style="margin-bottom: 3rem; border: 2px solid var(--primary-color);">
                <div class="card-header" style="background: var(--primary-color);">
                    <h2><i class="fas fa-file-signature"></i> Sign Our Petition</h2>
                </div>
                <div class="card-body">
                    <h3 style="color: var(--primary-color); margin-bottom: 1rem;"><?php echo htmlspecialchars($petition['title']); ?></h3>
                    <p style="margin-bottom: 1.5rem;"><?php echo htmlspecialchars($petition['description']); ?></p>
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
                        <div>
                            <strong>Signatures:</strong> <?php echo number_format($petition['current_signatures']); ?> / <?php echo number_format($petition['target_signatures']); ?>
                        </div>
                        <div style="flex: 1; min-width: 200px;">
                            <div style="background: #e0e0e0; height: 20px; border-radius: 10px; overflow: hidden;">
                                <div style="background: var(--success); height: 100%; width: <?php echo min(($petition['current_signatures'] / $petition['target_signatures']) * 100, 100); ?>%; transition: width 0.5s;"></div>
                            </div>
                        </div>
                    </div>
                    <?php if (is_logged_in()): ?>
                        <?php
                        $user_id = $_SESSION['user_id'];
                        $stmt = $pdo->prepare("SELECT * FROM petition_signatures WHERE petition_id = ? AND user_id = ?");
                        $stmt->execute([$petition['id'], $user_id]);
                        $already_signed = $stmt->rowCount() > 0;
                        ?>
                        <?php if ($already_signed): ?>
                            <button class="btn btn-success" disabled>You have already signed this petition ✓</button>
                        <?php else: ?>
                            <form method="POST" action="sign-petition.php">
                                <input type="hidden" name="petition_id" value="<?php echo $petition['id']; ?>">
                                <button type="submit" class="btn btn-primary">Sign Petition</button>
                            </form>
                        <?php endif; ?>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-primary">Login to Sign Petition</a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Donation Section -->
            <div class="card" style="background: linear-gradient(135deg, var(--primary-dark), var(--primary-color)); color: white;">
                <div class="card-body" style="text-align: center;">
                    <h2 style="margin-bottom: 1rem;">Support Our Cause</h2>
                    <p style="margin-bottom: 2rem; opacity: 0.9;">Your donation helps us organize cleanup events, educate communities, and advocate for policy changes.</p>
                    <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                        <a href="donate.php" class="btn" style="background: white; color: var(--primary-color);">Donate Now</a>
                        <a href="help.php" class="btn btn-outline" style="color: white; border-color: white;">Other Ways to Help</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>
