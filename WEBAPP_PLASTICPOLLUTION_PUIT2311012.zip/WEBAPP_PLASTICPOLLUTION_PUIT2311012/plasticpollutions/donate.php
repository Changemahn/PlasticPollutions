<?php
$page_title = 'Donate';
require_once 'includes/config.php';
require_once 'includes/functions.php';

$pdo = db();
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_login();
    
    $amount = floatval($_POST['amount'] ?? 0);
    $payment_method = sanitize_input($_POST['payment_method'] ?? 'card');
    $notes = sanitize_input($_POST['notes'] ?? '');
    
    // Validation
    if ($amount <= 0) {
        $errors[] = "Amount must be greater than 0";
    } elseif ($amount > 100000) {
        $errors[] = "Amount exceeds maximum limit";
    }
    
    if (!in_array($payment_method, ['card', 'mobile_money', 'bank_transfer'])) {
        $errors[] = "Invalid payment method";
    }
    
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO donations (user_id, amount, payment_method, notes, status) VALUES (?, ?, ?, ?, 'completed')");
            $stmt->execute([$_SESSION['user_id'], $amount, $payment_method, $notes]);
            
            $success = true;
            set_flash_message('success', 'Thank you for your donation of GHS ' . number_format($amount) . '! Your contribution helps us fight plastic pollution.');
        } catch (Exception $e) {
            $errors[] = "Donation failed: " . $e->getMessage();
        }
    }
}

// Get donation history if logged in
$donation_history = [];
$user_total = 0;
if (is_logged_in()) {
    $donation_history = get_user_donations($_SESSION['user_id']);
    $user_total = get_user_total_donations($_SESSION['user_id']);
}

$overall_total = get_total_donations();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Support PlasticPollutions by making a donation">
    <title>Donate - PlasticPollutions</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <section class="section" style="padding: 4rem 0;">
        <div class="container">
            <h1 style="text-align: center; margin-bottom: 1rem; color: var(--primary-color);">Support Our Cause</h1>
            <p style="text-align: center; max-width: 800px; margin: 0 auto 3rem; color: var(--text-light);">
                Your donation helps us organize cleanup events, educate communities, and advocate for policy changes to reduce plastic pollution.
            </p>
            
            <!-- Overall Statistics -->
            <div class="card" style="margin-bottom: 3rem; background: linear-gradient(135deg, var(--primary-dark), var(--primary-color)); color: white;">
                <div class="card-body" style="text-align: center;">
                    <h2 style="margin-bottom: 1rem;">Total Donations Raised</h2>
                    <div style="font-size: 3rem; font-weight: bold; margin-bottom: 0.5rem;">GHS <?php echo number_format($overall_total); ?></div>
                    <p style="opacity: 0.9;">Thank you to all our generous supporters!</p>
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 3rem;">
                <!-- Donation Form -->
                <div class="card">
                    <div class="card-header">
                        <h2>Make a Donation</h2>
                    </div>
                    <div class="card-body">
                        <?php if (has_flash_message('success')): ?>
                            <div class="alert alert-success">
                                <?php echo htmlspecialchars(get_flash_message('success')); ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <?php foreach ($errors as $error): ?>
                                    <p><?php echo htmlspecialchars($error); ?></p>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (is_logged_in()): ?>
                            <form method="POST" action="donate.php">
                                <div class="form-group">
                                    <label for="amount">Amount (GHS) *</label>
                                    <input type="number" id="amount" name="amount" class="form-control" 
                                           min="1" max="100000" step="0.01" required 
                                           placeholder="Enter amount">
                                </div>
                                
                                <div class="form-group">
                                    <label>Quick Select</label>
                                    <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                                        <button type="button" class="btn btn-outline" onclick="document.getElementById('amount').value = 10">GHS 10</button>
                                        <button type="button" class="btn btn-outline" onclick="document.getElementById('amount').value = 25">GHS 25</button>
                                        <button type="button" class="btn btn-outline" onclick="document.getElementById('amount').value = 50">GHS 50</button>
                                        <button type="button" class="btn btn-outline" onclick="document.getElementById('amount').value = 100">GHS 100</button>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label for="payment_method">Payment Method *</label>
                                    <select id="payment_method" name="payment_method" class="form-control" required>
                                        <option value="card">Credit/Debit Card</option>
                                        <option value="mobile_money">Mobile Money (MTN/Vodafone/AirtelTigo)</option>
                                        <option value="bank_transfer">Bank Transfer</option>
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <label for="notes">Notes (Optional)</label>
                                    <textarea id="notes" name="notes" class="form-control" rows="3" 
                                              placeholder="Any message you'd like to share..."></textarea>
                                </div>
                                
                                <button type="submit" class="btn btn-primary btn-block">
                                    <i class="fas fa-heart"></i> Donate Now
                                </button>
                            </form>
                        <?php else: ?>
                            <p style="margin-bottom: 1.5rem;">Please login to make a donation and track your contribution history.</p>
                            <a href="login.php" class="btn btn-primary btn-block">Login to Donate</a>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Donation History -->
                <div class="card">
                    <div class="card-header">
                        <h2>Your Donations</h2>
                    </div>
                    <div class="card-body">
                        <?php if (is_logged_in()): ?>
                            <div style="margin-bottom: 1.5rem; padding: 1rem; background: var(--bg-light); border-radius: var(--border-radius);">
                                <strong>Your Total Contributions:</strong> 
                                <span style="font-size: 1.5rem; color: var(--primary-color); font-weight: bold;">
                                    GHS <?php echo number_format($user_total); ?>
                                </span>
                            </div>
                            
                            <?php if (empty($donation_history)): ?>
                                <p style="color: var(--text-light); text-align: center; padding: 2rem;">
                                    You haven't made any donations yet. Make your first donation today!
                                </p>
                            <?php else: ?>
                                <div style="max-height: 400px; overflow-y: auto;">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Amount</th>
                                                <th>Method</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($donation_history as $donation): ?>
                                            <tr>
                                                <td><?php echo date('M d, Y', strtotime($donation['donation_date'])); ?></td>
                                                <td>GHS <?php echo number_format($donation['amount']); ?></td>
                                                <td><?php echo ucfirst(str_replace('_', ' ', $donation['payment_method'])); ?></td>
                                                <td>
                                                    <span style="color: <?php echo $donation['status'] === 'completed' ? 'var(--success)' : 'var(--warning)'; ?>;">
                                                        <?php echo ucfirst($donation['status']); ?>
                                                    </span>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <p style="color: var(--text-light); text-align: center; padding: 2rem;">
                                Login to view your donation history.
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Impact of Donations -->
            <div class="card" style="margin-top: 3rem;">
                <div class="card-header">
                    <h2>How Your Donation Helps</h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem;">
                        <div style="text-align: center; padding: 1.5rem;">
                            <i class="fas fa-trash-alt" style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                            <h3 style="margin-bottom: 0.5rem;">GHS 10</h3>
                            <p style="color: var(--text-light);">Helps remove 5kg of plastic waste from our beaches</p>
                        </div>
                        <div style="text-align: center; padding: 1.5rem;">
                            <i class="fas fa-users" style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                            <h3 style="margin-bottom: 0.5rem;">GHS 25</h3>
                            <p style="color: var(--text-light);">Educates 50 students about plastic pollution</p>
                        </div>
                        <div style="text-align: center; padding: 1.5rem;">
                            <i class="fas fa-hand-holding-heart" style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                            <h3 style="margin-bottom: 0.5rem;">GHS 50</h3>
                            <p style="color: var(--text-light);">Sponsors a community cleanup event</p>
                        </div>
                        <div style="text-align: center; padding: 1.5rem;">
                            <i class="fas fa-seedling" style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
                            <h3 style="margin-bottom: 0.5rem;">GHS 100</h3>
                            <p style="color: var(--text-light);">Plants 20 trees and restores natural habitat</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>
